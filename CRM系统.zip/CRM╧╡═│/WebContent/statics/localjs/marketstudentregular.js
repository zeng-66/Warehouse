 //验证姓名字段
      function checkNum(obj) {
	    console.log(obj);
	    var re =/^[\u4e00-\u9fa5]{2,4}$/;
	    console.log(obj.value);
	    if (!re.test(obj.value)) {
	    	obj.placeholder="输入格式错误，请输入2~4位中文";
	        obj.value = "";
	    }   
	}    
      
      function checkNum1(obj) {
		    console.log(obj);
		    var re =/^[\u4E00-\u9FA5A-Za-z]+$/;
		    console.log(obj.value);
		    if (!re.test(obj.value)) {
		    	obj.placeholder="输入格式错误，请输入中文或英文";
		        obj.value = "";
		    }   
		}
      function checkNum2(obj) {
		    console.log(obj);
		    var re =/^[A-Za-z]+$/;
		    console.log(obj.value);
		    if (!re.test(obj.value)) {
		    	obj.placeholder="输入格式错误，请输入姓名拼音";
		        obj.value = "";
		    }   
		}
      
      function checkNum4(obj) {
		    console.log(obj);
		    var re =/^[A-Za-z]+$/;
		    console.log(obj.value);
		    if (!re.test(obj.value)) {
		    	obj.placeholder="输入格式错误，请输入姓名拼音";
		        obj.value = "";
		    }   
		}
      
      function checkNum3(obj) {
		    console.log(obj);
		    var re =/^[0-9]{6,12}$/;
		    console.log(obj.value);
		    if (!re.test(obj.value)) {
		    	obj.placeholder="输入式错误，请输入6-12位数字";
		        obj.value = "";
		    }   
		}
function checkNum4(obj) {
		    console.log(obj);
		    var re =/^1(?:[3-9]\d|4[4-9]|5[0-35-9]|6[67]|7[013-8]|8\d|9\d)\d{8}$/;
		    console.log(obj.value);
		    if (!re.test(obj.value)) {
		    	obj.placeholder="输入格式错误，请输入13|14|15|17|18|19开头的11位数字";
		        obj.value = "";
		    }   
		}
		
		 
		$("#butt").click(function(){
			var studentName = $("#name").val()
			var marketId = $("#marketId").val()
			var marketClass = $("#marketClass").val()
			var fromSchool = $("#fromSchool").val()
			var education = $("#education").val()
			var phone = $("#phone").val()
			var qq = $("#qq").val()
			var xingge = $("#xingge").val()
			var beizhu = $("#beizhu").val()
			var willTrain = $("#willTrain").val()
			
        if(studentName.length==0){
            alert("姓名不能为空")
            return false;
        }
		if(marketId.length==0){
			alert("市场类型不能为空")
			return false;
		}
		if(marketClass.length==0){
			alert("班级不能为空")
			return false;
		}
         if(fromSchool.length==0){
            alert("学校不能为空")
            return false;
        }
         if(education.length==0){
            alert("学历不能为空")
            return false;
        }
         if(phone.length==0){
        	 alert("电话不能为空")
        	 return false;
         }
         if(qq.length==0){
        	 alert("QQ不能为空")
        	 return false;
         }
         if(xingge.length==0){
        	 alert("性格不能为空")
        	 return false;
         }
         if(xingge.length==0){
        	 alert("性格不能为空")
        	 return false;
         }
         if(beizhu.length==0){
        	 alert("备注不能为空")
        	 return false;
         }
         if(willTrain.length==0){
        	 alert("意向不能为空")
        	 return false;
         }
         
    });