
		
		$("#daochu").click(function(){
		var studyType=$("#zhuanye").val()
		 var classId = $("#banji").val()
        var studentName = $("#shijiandata").val()
        if(studentName.length==0){
            alert("姓名不能为空")
            return false;
        }
         if(fromSchool.length==0){
            alert("学校不能为空")
            return false;
        }
         if(education.length==0){
            alert("学历不能为空")
            return false;
        }
         
    });
    
    

    