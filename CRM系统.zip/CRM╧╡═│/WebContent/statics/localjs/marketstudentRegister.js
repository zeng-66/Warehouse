$(function(){
	$("#marketId").change(function() {
		var marketId = $("#marketId").val();
		if(null!=marketId&&marketId!=""){
			$(function(){
		    	  $.getJSON("getMarketClassbyId.json","type="+marketId,function(data){
		    		  $("#marketClass").html("");
					  var options = "<option value=''>--请选择--</option>";
					  for(i=0;i<data.length;i++){
						  options+="<option value="+data[i].mkClassId+">"+data[i].className+"</option>";
					  }
					  $("#marketClass").html(options);
		  		})
			});
		}else{
			//假设没有科目，下边是请选择
			$("#marketClass").html("");
			var options = "<option value=''>--请选择--</option>";
			$("#marketClass").html(options);
		}
	})
	
	//表单提交验证
	$("#demo-form2").submit(function(){
		   var studytype=$("#studyType").val();
		   if(null==studytype||""==studytype){
			   alert("请选择专业类型再查询");
			   return false;
		   }
		   return true;
	   }); 
})

//<c:if test="${param.classId eq data[i].classId}">selected="selected"</c:if>