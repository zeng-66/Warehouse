$(function(){
	$("#studyType").change(function() {
		var studytype = $("#studyType").val();
		if(null!=studytype&&studytype!=""){
			$(function(){
		    	  $.getJSON("getClassnamebyType.json","type="+studytype,function(data){
		    		  $("#querySoftWareName").html("");
					  var options = "<option value=''>--请选择--</option>";
					  for(i=0;i<data.length;i++){
						  options+="<option value="+data[i].classId+">"+data[i].className+"</option>";
					  }
					  $("#querySoftWareName").html(options);
		  		})
			});
		}else{
			//假设没有科目，下边是请选择
			$("#querySoftWareName").html("");
			var options = "<option value=''>--请选择--</option>";
			$("#querySoftWareName").html(options);
		}
	});
		
		$("#zhuanye").change(function() {
			var studytype2 = $("#zhuanye").val();
			if(null!=studytype2&&studytype2!=""){
				$(function(){
			    	  $.getJSON("getClassnamebyType.json","type="+studytype2,function(data){
			    		  $("#banji").html("");
						  var options = "<option value=''>--请选择--</option>";
						  for(i=0;i<data.length;i++){
							  options+="<option value="+data[i].classId+">"+data[i].className+"</option>";
						  }
						  $("#banji").html(options);
			  		})
				});
			}else{
				//假设没有科目，下边是请选择
				$("#banji").html("");
				var options = "<option value=''>--请选择--</option>";
				$("#banji").html(options);
			}
	})
	
	//表单提交验证
	$("#demo-form2").submit(function(){
		   var studytype=$("#studyType").val();
		   if(null==studytype||""==studytype){
			   alert("请选择专业类型再查询");
			   return false;
		   }
		   return true;
	   }); 
})
//<c:if test="${param.classId eq data[i].classId}">selected="selected"</c:if>