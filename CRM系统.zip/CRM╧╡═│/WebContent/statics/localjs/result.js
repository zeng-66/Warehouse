
		
		$("#daochu").click(function(){
		var studyType=$("#zhuanye").val()
		 var classId = $("#banji").val()
        var studentName = $("#shijiandata").val()
        if(studentName.length==0){
            alert("日期不能为空")
            return false;
        }
         if(classId.length==0){
            alert("班级不能为空")
            return false;
        }
         if(studyType.length==0){
            alert("专业不能为空")
            return false;
        }
         
    });
    
    

    