 //验证姓名字段
      function checkNum(obj) {
	    console.log(obj);
	    var re =/^[\u4e00-\u9fa5]{2,4}$/;
	    console.log(obj.value);
	    if (!re.test(obj.value)) {
	    	obj.placeholder="输入格式错误，请输入2~4位中文";
	        obj.value = "";
	    }   
	}    
      
      function checkNum1(obj) {
		    console.log(obj);
		    var re =/^[\u4E00-\u9FA5A-Za-z]+$/;
		    console.log(obj.value);
		    if (!re.test(obj.value)) {
		    	obj.placeholder="输入格式错误，请输入中文或英文";
		        obj.value = "";
		    }   
		}
      function checkNum2(obj) {
		    console.log(obj);
		    var re =/^[A-Za-z]+$/;
		    console.log(obj.value);
		    if (!re.test(obj.value)) {
		    	obj.placeholder="输入格式错误，请输入姓名拼音";
		        obj.value = "";
		    }   
		}
      
      function checkNum3(obj) {
		    console.log(obj);
		    var re =/^[A-Za-z0-9]{6,12}$/;
		    console.log(obj.value);
		    if (!re.test(obj.value)) {
		    	obj.placeholder="输入格式错误，请输入6-12位数字";
		        obj.value = "";
		    }   
		}
		
		$("#butt").click(function(){
		var studyType=$("#studyType").val()
		 var classId = $("#querySoftWareName").val()
        var studentName = $("#email").val()
        var fromSchool = $("#email2").val()
        var education = $("#name").val()
        var loginCode = $("#website").val()
        var password = $("#occupation").val()
        if(studentName.length==0){
            alert("姓名不能为空")
            return false;
        }
         if(fromSchool.length==0){
            alert("学校不能为空")
            return false;
        }
         if(education.length==0){
            alert("学历不能为空")
            return false;
        }
         if(loginCode.length==0){
            alert("登录账号不能为空")
            return false;
        }
         if(studyType.length==0){
            alert("专业不能为空")
            return false;
        }
        if(password.length==0){
            alert("密码不能为空")
            return false;
        }
         if(classId.length==0){
            alert("班级不能为空")
            return false;
        }
    });
    
    
    function checkNum4(obj) {
	    console.log(obj);
	    var re =/^[\u4e00-\u9fa5]$/;
	    console.log(obj.value);
	    if (!re.test(obj.value)) {
	    	obj.placeholder="请输入正确中文";
	        obj.value = "";
	    }   
	} 
    
    