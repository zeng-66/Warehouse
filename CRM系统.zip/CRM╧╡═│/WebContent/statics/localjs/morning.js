
				    var getChks = function(id) {
					var diva = document.getElementById(id);
					var chks = diva.getElementsByTagName("input");
					var arr = [];
					for (var idx = 0; idx < chks.length; idx++) {
						var chk = chks[idx];

						if (chk.checked) {
							arr.push({
								idx : chk.value,
							});
						}
					}
					return arr;
				}
				window.onload = function() {
					tj1.onclick = function() {
						var arrA = getChks("a");
						$.ajax({
							type : 'POST',
							url : 'Morming.do',
							data : "arrA=" + JSON.stringify(arrA) + ",result="
									+ 70,
							success : function(data) {
							}
						});
					};
					tj2.onclick = function() {
						var arrA = getChks("a");
						$.ajax({
							type : 'POST',
							url : 'Morming.do',
							data : "arrA=" + JSON.stringify(arrA) + ",result="
									+ 80,
							success : function(data) {
							}
						});
					};
					tj3.onclick = function() {
						var arrA = getChks("a");
						$.ajax({
							type : 'POST',
							url : 'Morming.do',
							data : "arrA=" + JSON.stringify(arrA) + ",result="
									+ 90,
							success : function(data) {
							}
						});
					};
					tj4.onclick = function() {
						var arrA = getChks("a");
						$.ajax({
							type : 'POST',
							url : 'Morming.do',
							data : "arrA=" + JSON.stringify(arrA) + ",result="
									+ 100,
							success : function(data) {
							}
						});
					};
				};
				

				
				
				
				