package zte.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.excel.EasyExcel;

import zte.dao.excel.KaoQinEXImpDao;
import zte.dao.excel.KaoQinExDao;
import zte.utils.CheckVoEX;

@WebServlet("/kaoqinexcel.do")
public class CheckExcelServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String major = request.getParameter("majorse");
		String classid = request.getParameter("classId");
		String stuName = request.getParameter("studentname");
		String dateinfo = request.getParameter("data");
		System.out.println("ʱ��" + dateinfo);
		String statu = request.getParameter("result");
//		Integer curpage=Integer.parseInt(request.getParameter("pageIndex"));
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		String downLoadTime = sf.format(new Date());
		KaoQinExDao dao = new KaoQinEXImpDao();
		int size = dao.getCheckVoCount(major, classid, stuName, dateinfo, statu);
		List<CheckVoEX> kaoList = dao.getCheckVoList(0, size, major, classid, stuName, dateinfo, statu);
		response.setContentType("application/vnd.ms-excel"); // excel 的响应头
		response.setCharacterEncoding("utf-8");
		String fileName = "student_" + downLoadTime + ".xlsx";
		response.setHeader("Content-disposition", "attachment;filename=" + fileName);
		EasyExcel.write(response.getOutputStream(), CheckVoEX.class).sheet("ѧ����Ϣ").doWrite(kaoList);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
