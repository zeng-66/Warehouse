package zte.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import zte.service.classinfo.ClassInfoBiz;
import zte.service.classinfo.ClassInfoBizImpl;

/**
 * �༶����ɾ������
 * 
 * @author zeng
 *
 */
@WebServlet("/exeUpdateMajorClassServlet")
public class ExeUpdateMajorClassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		// ��ȡ�༶id
		String classId = request.getParameter("classId");
		ClassInfoBiz classInfoBiz = new ClassInfoBizImpl();
		ClassInfoBiz pdClass = new ClassInfoBizImpl();
		// �жϸð༶�Ƿ���ѧ��
		boolean bol = pdClass.pdClass(classId);
		if (bol) {
			// ��ѧ�����ClassInfoVOmajorInfoServlet �����ź�Inf=1 ��������ɾ�����ź�
			request.setAttribute("Inf", "1");
			request.getRequestDispatcher("ClassInfoVOmajorInfoServlet").forward(request, response);
		} else {
			// û��ѧ�����ClassInfoVOmajorInfoServlet �����ź�Inf=4��������ɾ�����ź�
			boolean bool = classInfoBiz.delete(classId);
			if (bool) {
				request.setAttribute("Inf", "4");
				request.getRequestDispatcher("ClassInfoVOmajorInfoServlet").forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
