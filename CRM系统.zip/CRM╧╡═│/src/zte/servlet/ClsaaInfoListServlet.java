package zte.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import zte.dao.major.MajorDao;
import zte.dao.major.MajorDaoImpl;
import zte.entity.ClassInfo;
import zte.entity.Major;
import zte.service.classinfo.ClassInfoBiz;
import zte.service.classinfo.ClassInfoBizImpl;

/**
 * ��ѯ�༶����
 * 
 * @author zeng
 *
 */
@WebServlet("/ClsaaInfoListServlet")
public class ClsaaInfoListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		MajorDao majordao = new MajorDaoImpl();
		List<Major> MajorList = majordao.ShowInfo();
		ClassInfoBiz ClassInfoBiz = new ClassInfoBizImpl();
		// ���ݿ�Ŀ�����ѯ��Ŀ��
		String studyType = request.getParameter("studyType");
		List<ClassInfo> ClassInfobyType = ClassInfoBiz.ShowInfo(studyType);
		if (MajorList != null) {
			request.setAttribute("majorList", MajorList);
			request.setAttribute("classInfobyType", ClassInfobyType);
			request.getRequestDispatcher("./studentManager/studentRegister.jsp").forward(request, response);
			return;
		} else {
			response.sendRedirect("main.jsp");
			return;
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);

	}

}
