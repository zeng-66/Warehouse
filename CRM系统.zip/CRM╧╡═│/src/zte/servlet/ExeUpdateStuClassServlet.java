package zte.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import zte.dao.classInfo.ClassInfoDao;
import zte.dao.classInfo.ClassInfoDaoImpl;
import zte.entity.ClassInfo;
import zte.entity.Major;
import zte.entity.Student;
import zte.entity.VO.StudentVOclassInfo;
import zte.service.OV.studentOVclassInfo.StudentVOclassInfoBiz;
import zte.service.OV.studentOVclassInfo.StudentVOclassInfoBizImpl;
import zte.service.classinfo.ClassInfoBiz;
import zte.service.classinfo.ClassInfoBizImpl;
import zte.service.major.MajorBiz;
import zte.service.major.MajorBizImpl;
import zte.service.student.StudentBiz;
import zte.service.student.StudentBizImpl;

/**
 * ѧ����Ϣ����ҳ����ɾ��
 * 
 * @author zeng
 *
 */
@WebServlet("/exeUpdateServlet.do")
public class ExeUpdateStuClassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		// ��ȡѧ��
		String stuNo = request.getParameter("stuNo");
		// ��ȡInfo�����ж�InfoΪ�Ǹ��ַ����Ӷ��ж�ִ����Ӧ�����
		// 1--�޸� 2--�鿴 3--ɾ��
		// 4--��ȡ�༶��Ϣ�Լ���Ҫ�޸ĵ�ѧ����Ϣ��ת���޸�ҳ��
		String Info = request.getParameter("Info");

		// ��ȡרҵ��
		MajorBiz majordao = new MajorBizImpl();
		List<Major> MajorList = majordao.ShowInfo();

		// 1--�޸�
		if ("1".equals(Info)) {
			// ����רҵ��
			request.setAttribute("majorList", MajorList);
			// ��ȡҳ���ֵ
			String classId = request.getParameter("classId");
			String studentName = request.getParameter("studentName");
			String fromSchool = request.getParameter("fromSchool");
			String education = request.getParameter("education");
			String loginCode = request.getParameter("loginCode");
			String password = request.getParameter("password");
			String studyType = request.getParameter("studyType");

			// ����Student�����ֵװ����
			Student student = new Student(stuNo, classId, studentName, fromSchool, education, loginCode, password);
			// �Ѷ����޸ķ���
			boolean bool = new StudentBizImpl().updateStudentInfo(student);
			if (bool) {
				request.setAttribute("errer", "�޸ĳɹ���");
				request.getRequestDispatcher("ChastudentOVclassInfoList.do").forward(request, response);
			} else {
				request.setAttribute("errer", "�޸�ʧ�ܣ�");
				request.getRequestDispatcher("studentManager/studentAndclassInfo.jsp");
			}

		}

		// 2--�鿴
		if ("2".equals(Info)) {
			StudentVOclassInfoBiz studentOVclass = new StudentVOclassInfoBizImpl();
			StudentVOclassInfo studentInfo = studentOVclass.getStudentInfo(stuNo);

			// ����רҵ��
			request.setAttribute("majorList", MajorList);
			if (null != studentInfo) {
				HttpSession session = request.getSession();
				session.setAttribute("studentInfo", studentInfo);
				request.getRequestDispatcher("studentManager/studentInfo.jsp").forward(request, response);
			} else {
				request.setAttribute("errer", "ɾ��ʧ�ܣ�");
				request.getRequestDispatcher("studentManager/studentAndclassInfo.jsp");
			}
		}

		// 3--ɾ��
		if ("3".equals(Info)) {

			// ����רҵ��
			request.setAttribute("majorList", MajorList);
			StudentBiz studentBiz = new StudentBizImpl();
			boolean bool = studentBiz.delete(stuNo);
			if (bool) {
				response.sendRedirect("ChastudentOVclassInfoList.do");
			} else {
				request.setAttribute("errer", "ɾ��ʧ�ܣ�");
				request.getRequestDispatcher("studentManager/studentAndclassInfo.jsp");
			}
		}

		// 4--��ȡ�༶��Ϣ�Լ���Ҫ�޸ĵ�ѧ����Ϣ��ת���޸�ҳ��
		if ("4".equals(Info)) {
			String studyType = request.getParameter("studyType");
			String classId = request.getParameter("classId");

			// �������ͻ�ȡ�γ���Ϣ
			ClassInfoDao ClassInfoDao = new ClassInfoDaoImpl();
			List<ClassInfo> ClassInfobyType = ClassInfoDao.GetClassByName(studyType);

			// ����רҵ��
			request.setAttribute("majorList", MajorList);
			StudentVOclassInfo student = new StudentVOclassInfoBizImpl().getStudentInfo(stuNo);
			List<ClassInfo> ClassList = new ClassInfoBizImpl().ShowInfo();
			request.setAttribute("student", student);
			request.setAttribute("studyType", studyType);
			request.setAttribute("classInfobyType", ClassInfobyType);
			request.setAttribute("banji", classId);
			request.setAttribute("classInfo", ClassList);
			request.getRequestDispatcher("studentManager/updateStudentInfo.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
