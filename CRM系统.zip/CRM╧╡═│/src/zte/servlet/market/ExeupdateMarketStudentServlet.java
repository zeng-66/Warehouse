package zte.servlet.market;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import zte.entity.MarketStudent;
import zte.dao.MarketClass.MarketclassDao;
import zte.dao.MarketClass.MarketclassDaolmpl;
import zte.entity.MarketClass;
import zte.entity.VO.MarketStudentVOmarketClass;
import zte.service.OV.marketStudentVOmarketClass.MarketStudentVOmarketClassBiz;
import zte.service.OV.marketStudentVOmarketClass.MarketStudentVOmarketClassBizImpl;
import zte.service.marketstudent.MarketStudentBiz;
import zte.service.marketstudent.MarketStudentBizImpl;
import zte.service.student.StudentBizImpl;

@WebServlet("/exeupdateMarketStudentServlet.do")
public class ExeupdateMarketStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		// ��ȡѧ��
		String studentId = request.getParameter("studentId");
		// ��ȡInfo���� 1--�޸� 2--�鿴 3--ɾ�� 4--��ȡ�༶��Ϣ�Լ���Ҫ�޸ĵ�ѧ����Ϣ
		// �ж�InfoΪ�Ǹ��ַ����Ӷ��ж�ִ����Ӧ�����
		String Info = request.getParameter("Info");

		// �޸�
		if ("1".equals(Info)) {
			// ��ȡҳ���ֵ
			String stuname = request.getParameter("stuname");
			String marketId = request.getParameter("marketId");
			String classId = request.getParameter("classId");
			String fromSchool = request.getParameter("fromSchool");
			String education = request.getParameter("education");
			String phone = request.getParameter("phone");
			String qq = request.getParameter("qq");
			String xingge = request.getParameter("xingge");
			String beizhu = request.getParameter("beizhu");
			String willTrain = request.getParameter("willTrain");
			String username = (String) request.getSession().getAttribute("loginuser");
			String modifyauthorTime = request.getParameter("modifyauthorTime");
			String studentId1 = request.getParameter("studentId");

			// ����Student�����ֵװ����
//			MarketStudent marketStudent=new MarketStudent(stuname, classId, fromSchool, education, phone, qq, xingge, beizhu, willTrain, username, modifyauthorTime, marketId);
			MarketStudent marketStudent = new MarketStudent();
			marketStudent.setStudentName(stuname);
//			marketStudent.setMkClassId(marketId);
			marketStudent.setMkClassId(classId);
			marketStudent.setFromschool(fromSchool);
			marketStudent.setEducation(education);
			marketStudent.setPhone(phone);
			marketStudent.setQq(qq);
			marketStudent.setXinge(xingge);
			marketStudent.setBeizhu(beizhu);
			marketStudent.setWilltrain(willTrain);
			marketStudent.setModifyauthor(username);
			marketStudent.setModifyauthorTime(modifyauthorTime);
			marketStudent.setStudentId(studentId1);
			// �Ѷ����޸ķ���
			boolean flag = new MarketStudentBizImpl().updateStudentInfo(marketStudent);
			if (flag) {
				request.setAttribute("success", "�޸ĳɹ���");
				request.getRequestDispatcher("chamarketStudentVOmarketClassServlet.do").forward(request, response);
			} else {
				request.setAttribute("success", "�޸�ʧ�ܣ�");
				request.getRequestDispatcher("chamarketStudentVOmarketClassServlet.do");
			}
		}

		// �鿴
		if ("2".equals(Info)) {
			MarketStudentVOmarketClassBiz biz = new MarketStudentVOmarketClassBizImpl();
			MarketStudentVOmarketClass studentInfo = biz.getstudentInfo(studentId);
			String classType = request.getParameter("classType");
			if (classType.equals("1")) {
				classType = "��У";
			} else if (classType.equals("2")) {
				classType = "ѵ��Ӫ";
			}
			if (studentInfo != null) {
				HttpSession session = request.getSession();
				session.setAttribute("studentInfo", studentInfo);
				request.setAttribute("classType", classType);
				request.getRequestDispatcher("market/marketstudentdetail.jsp").forward(request, response);
			} else {
				request.setAttribute("success", "�鿴ʧ�ܣ�");
				request.getRequestDispatcher("market/marketstudentdetail.jsp");
			}
		}

		// ɾ��
		if ("3".equals(Info)) {
			MarketStudentBiz marketStudentBiz = new MarketStudentBizImpl();
			boolean flag = marketStudentBiz.delete(studentId);
			if (flag) {
				request.getRequestDispatcher("chamarketStudentVOmarketClassServlet.do").forward(request, response);
			} else {
				request.setAttribute("errer", "ɾ��ʧ�ܣ�");
				response.sendRedirect("chamarketStudentVOmarketClassServlet.do");
			}
		}

		// ��ȡ�༶��Ϣ�Լ���Ҫ�޸ĵ�ѧ����Ϣ
		if ("4".equals(Info)) {
			MarketStudentVOmarketClass marketStudent = new MarketStudentVOmarketClassBizImpl()
					.getstudentInfo(studentId);
			MarketclassDao marketclassDao = new MarketclassDaolmpl();
			String classId = request.getParameter("classId");
			String classType = request.getParameter("classType");
			List<MarketClass> marketClassInfo = marketclassDao.getMarketclassbyId(classType);
			request.setAttribute("classId", classId);
			request.setAttribute("classType", classType);
			request.setAttribute("marketStudent", marketStudent);
			request.setAttribute("marketClassInfo", marketClassInfo);
			request.getRequestDispatcher("market/marketstudentEdit.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
