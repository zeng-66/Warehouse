package zte.servlet.market;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import zte.dao.MarketClass.MarketclassDao;
import zte.dao.MarketClass.MarketclassDaolmpl;
import zte.entity.ClassInfo;
import zte.entity.MarketClass;
import zte.service.classinfo.ClassInfoBiz;
import zte.service.classinfo.ClassInfoBizImpl;

@WebServlet("/getMarketClassbyId.json")
public class GetMarketClassbyId extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		String marketId = request.getParameter("type");
		MarketclassDao MarketclassDao = new MarketclassDaolmpl();

		List<MarketClass> MarketclassList = MarketclassDao.getMarketclassbyId(marketId);
		// ���ݿ�Ŀ�����ѯ��Ŀ��������json��ʽ����

		String MarketclassInfo = JSON.toJSONString(MarketclassList);
		// ������ͻ���
		PrintWriter out = response.getWriter();
		out.print(MarketclassInfo);
		out.flush();
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
