package zte.servlet.market;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zte.entity.MarketStudent;
import zte.service.marketstudent.MarketStudentBiz;
import zte.service.marketstudent.MarketStudentBizImpl;

@WebServlet("/addMarketStudentServlet")
public class AddMarketStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡҳ���ֵ
		request.setCharacterEncoding("utf-8");
		String studentName = request.getParameter("stuname");
		// String marketId=request.getParameter("marketId");
		String classId = request.getParameter("classId");
		String fromSchool = request.getParameter("fromSchool");
		String education = request.getParameter("education");
		String phone = request.getParameter("phone");
		String qq = request.getParameter("qq");
		String xingge = request.getParameter("xingge");
		String beizhu = request.getParameter("beizhu");
		String willTrain = request.getParameter("willTrain");
		String date = request.getParameter("date");
		String username = (String) request.getSession().getAttribute("loginuser");

		// �Ѳ���װ����������
		MarketStudent marketStudent = new MarketStudent();
		marketStudent.setStudentName(studentName);
		// marketStudent.setMkClassId(marketId);
		marketStudent.setMkClassId(classId);
		marketStudent.setFromschool(fromSchool);
		marketStudent.setEducation(education);
		marketStudent.setPhone(phone);
		marketStudent.setQq(qq);
		marketStudent.setXinge(xingge);
		marketStudent.setBeizhu(beizhu);
		marketStudent.setWilltrain(willTrain);
		marketStudent.setCreateTime(date);
		marketStudent.setCreateauthorID(username);

		MarketStudentBiz marketStudentBiz = new MarketStudentBizImpl();
		boolean flag = marketStudentBiz.addMarketStudent(marketStudent);
		if (!flag) {
			request.setAttribute("success", "ע��ʧ�ܣ�");
			request.getRequestDispatcher("./chamarketStudentVOmarketClassServlet.do").forward(request, response);
		} else {
			request.setAttribute("success", "ע��ɹ���");
			request.getRequestDispatcher("./chamarketStudentVOmarketClassServlet.do").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
