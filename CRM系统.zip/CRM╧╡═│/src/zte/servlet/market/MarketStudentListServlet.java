package zte.servlet.market;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zte.dao.admin.AdminDao;
import zte.dao.admin.AdminDaoImpl;
import zte.entity.Admin;
import zte.service.admin.AdminBiz;
import zte.service.admin.AdminBizImpl;

@WebServlet("/marketStudentListServlet.do")
public class MarketStudentListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//		int roleid = 0;
//		AdminDao adminDao=new AdminDaoImpl();
//		List<Admin> login=new ArrayList<Admin>();
//		login=adminDao.showlogin(roleid);
		request.getRequestDispatcher("market/marketstudentRegister.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
