package zte.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zte.dao.MarketClass.MarketclassDao;
import zte.dao.MarketClass.MarketclassDaolmpl;
import zte.service.classinfo.ClassInfoBiz;
import zte.service.classinfo.ClassInfoBizImpl;
import zte.service.student.StudentBiz;
import zte.service.student.StudentBizImpl;

@WebServlet("/shichangexeup")
public class Shichangexeup extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		// ��ȡ�༶id
		String classId = request.getParameter("classId");

//		ClassInfoBiz classInfoBiz = new ClassInfoBizImpl();
		MarketclassDao marketclassDao = new MarketclassDaolmpl();

		ClassInfoBiz pdClass = new ClassInfoBizImpl();

		MarketclassDao MarketclassDao1 = new MarketclassDaolmpl();
		boolean bol = MarketclassDao1.pdClass(classId);

		if (bol) {
			request.setAttribute("Inf", "1");
			request.getRequestDispatcher("shichangclass1").forward(request, response);
		} else {
			boolean bool = marketclassDao.delete(classId);
			if (bool) {
				request.setAttribute("Inf", "4");
				request.getRequestDispatcher("shichangclass1").forward(request, response);

			}

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
