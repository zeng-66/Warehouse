package zte.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import zte.entity.Admin;
import zte.service.admin.AdminBiz;
import zte.service.admin.AdminBizImpl;

@WebServlet("/adminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if ("login".equals(action)) {
			loginAction(request, response);
		}

	}

	/**
	 * ��¼
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void loginAction(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		String loginCode = request.getParameter("loginCode");
		String password = request.getParameter("password");
		AdminBiz adminBiz = new AdminBizImpl();
		Admin user = adminBiz.login(loginCode, password);
		if (user != null) {
			HttpSession session = request.getSession();
			session.setAttribute("userSession", user);
			session.setAttribute("loginuser", loginCode);
			response.sendRedirect("main.jsp");
		} else {
			HttpSession session = request.getSession();
			session.setAttribute("error", "�û������������");
			response.sendRedirect("login.jsp");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
