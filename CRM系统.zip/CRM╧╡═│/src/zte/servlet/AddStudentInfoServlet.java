package zte.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zte.entity.Student;
import zte.service.student.StudentBiz;
import zte.service.student.StudentBizImpl;

@WebServlet("/AddStudentInfoServlet.do")
public class AddStudentInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡҳ���ֵ
		request.setCharacterEncoding("utf-8");
		String classId = request.getParameter("classId");
		String studentName = request.getParameter("studentName");
		String fromSchool = request.getParameter("fromSchool");
		String education = request.getParameter("education");
		String loginCode = request.getParameter("loginCode");
		String password = request.getParameter("password");

		// �Ѳ���ײ����������
		Student student = new Student();
		student.setClassId(classId);
		student.setStudentName(studentName);
		student.setFromSchool(fromSchool);
		student.setEducation(education);
		student.setLoginCode(loginCode);
		student.setPassword(password);
		StudentBiz stuService = new StudentBizImpl();
		boolean flag = stuService.AddStudent(student);
		if (!flag) {
			request.setAttribute("success", "ע��ʧ�ܣ�");
			request.getRequestDispatcher("./studentManager/studentRegister.jsp").forward(request, response);
		} else {
			request.setAttribute("success", "ע��ɹ���");
			request.getRequestDispatcher("./ClsaaInfoListServlet").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
