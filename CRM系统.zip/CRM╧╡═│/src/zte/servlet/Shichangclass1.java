package zte.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import zte.dao.MarketClass.MarketclassDao;
import zte.dao.MarketClass.MarketclassDaolmpl;
import zte.dao.VO.studentVOclassInfo.StudentVOclassInfoDaoImpl;
import zte.entity.ClassInfo;
import zte.entity.Major;
import zte.entity.MarketClass;
import zte.entity.VO.ClassInfoVOmajorInfo;
import zte.entity.VO.StudentVOclassInfo;
import zte.service.OV.classInfoOVmajorInfo.ClassInfoVOmajorInfoBiz;
import zte.service.OV.classInfoOVmajorInfo.ClassInfoVOmajorInfoBizImpl;
import zte.service.OV.studentOVclassInfo.StudentVOclassInfoBizImpl;
import zte.service.classinfo.ClassInfoBiz;
import zte.service.classinfo.ClassInfoBizImpl;
import zte.service.major.MajorBizImpl;
import zte.service.student.StudentBiz;
import zte.service.student.StudentBizImpl;
import zte.utils.ConStant;
import zte.utils.PageSupport;

@WebServlet("/shichangclass1")
public class Shichangclass1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		// Info��ֵȡ����ִ��ʲô���� 1--��ѯ 2--�鿴���� 3--�޸� 4--ɾ�� 5--���Ӱ༶ 6--js�ж� 7--��ѯרҵ������Ϣ
		String Info = request.getParameter("Info");

		String Inf = (String) request.getAttribute("Inf");
		String errer = (String) request.getAttribute("errer");

		request.setAttribute("ere", null);
		if (errer != null) {
			request.setAttribute("eree", "2");
		} else if (Inf != null && Inf.equals("1")) {
			request.setAttribute("ere", "1");
		}
		if (Inf != null) {
			switch (Inf) {
			case "1":
				Info = Inf;
				break;
			case "4":
				Info = "1";
				break;
			default:
				break;
			}
		}

		switch (Info) {
		case "1":// 1--��ѯ
			cha(request, response);
			break;
		case "2":// 2--�鿴����
			details(request, response);
			break;
		case "3":// 3--�޸�
			updata(request, response);
			break;
		case "4":// 4--ɾ��
			deleteClassInfo(request, response);
			break;
		case "5":// 5--���Ӱ༶
			try {
				addClass(request, response);
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
			break;
		case "6":// 6---js�ж�
			jsPanDuan(request, response);
			break;
		case "7":// ��ѯרҵ������Ϣ
			List<MarketClass> marketClass = new MarketclassDaolmpl().addclass();
			if (null != marketClass) {
				request.setAttribute("marketClass", marketClass);
				request.getRequestDispatcher("studentManager/shichangzylexx.jsp").forward(request, response);
			}
			break;
		case "8":// 8--��ȡ��Ҫ�޸İ༶��Ϣ
			getInfo(request, response);
			break;
		default:
			break;
		}

	}

	private void deleteClassInfo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡ�༶���
		String classId = request.getParameter("classId");
		StudentBiz studentBiz = new StudentBizImpl();
		ClassInfoBiz pdClass = new ClassInfoBizImpl();
		boolean bol = false;
		if (null != classId && !"".equals(classId)) {
			bol = pdClass.pdClass(classId);
		}
		if (bol) {
			request.setAttribute("Inf", "1");
			request.getRequestDispatcher("shichangclass1").forward(request, response);
		} else {
			boolean bool = studentBiz.delete(classId);
			if (bool) {
				this.cha(request, response);

			} else {
				this.cha(request, response);
//				request.setAttribute("errer", "ɾ��ʧ�ܣ�");
//				request.getRequestDispatcher("studentManager/studentAndclassInfo.jsp");
			}

		}
	}

	private void updata(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ��ȡҳ���ֵ
		String ClassId = request.getParameter("classId");
		String ClassName = request.getParameter("className");
		String studyType = request.getParameter("studyType");
		boolean bool = false;
		if (null != ClassId && !"".equals(ClassId) && null != ClassName && !"".equals(ClassName) && null != studyType
				&& !"".equals(studyType)) {
			// ����Student�����ֵװ����
//			ClassInfo classInfo = new ClassInfo(Integer.parseInt(ClassId), ClassName, Integer.parseInt(studyType));
			// �Ѷ����޸ķ���
			bool = new MarketclassDaolmpl().updateClassInfo(ClassId, ClassName, studyType);
//			 bool = new ClassInfoBizImpl().updateClassInfo(classInfo);
		}
		if (bool) {
			this.cha(request, response);
		} else {
			request.setAttribute("errer", "�޸�ʧ�ܣ�");
			request.setAttribute("Info", "1");
			request.getRequestDispatcher("shichangclass1").forward(request, response);
		}

	}

	private void getInfo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡѧ��
		String className = request.getParameter("className");
		String classId = request.getParameter("classId");

		List<MarketClass> marketClass = new MarketclassDaolmpl().addclass();
		request.setAttribute("classId", classId);
		request.setAttribute("className", className);
		request.setAttribute("marketClass", marketClass);
		request.getRequestDispatcher("studentManager/shichangtanchuan.jsp").forward(request, response);

	}

	private void jsPanDuan(HttpServletRequest request, HttpServletResponse response) throws IOException {
		List<MarketClass> marketClass = new MarketclassDaolmpl().ShowInfo();
		String result = "";
		Gson gson = new Gson();
		// ��ȡ�༶����
		String className = request.getParameter("className");
		for (MarketClass list : marketClass) {
			if (className.equals(list.getClassName())) {
				result = "exists";
				result = gson.toJson(result);
				break;
			} else {
				result = "";
				result = gson.toJson(result);
			}
		}
		response.getWriter().write(result);

	}

	private List<Major> chaMajorList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Major> MajorList = new MajorBizImpl().ShowInfo();

		return MajorList;

	}

	private void addClass(HttpServletRequest request, HttpServletResponse response)
			throws IOException, InterruptedException, ServletException {
		request.setCharacterEncoding("utf-8");
		// ��ȡҳ������
		// ��ȡרҵ����
		String studytype = request.getParameter("studytype");
		// ��ȡ�༶����
		String className = request.getParameter("className");
//		int type = Integer.parseInt(studytype);
//		ClassInfo classInfo = new ClassInfo();
//		classInfo.setClassType(type);
//		classInfo.setClassName(className);
		if (null != studytype) {
			boolean bool = new MarketclassDaolmpl().addClass(className, studytype);
			if (bool) {
				List<MarketClass> marketClass = new MarketclassDaolmpl().addclass();
				if (null != marketClass) {
					request.setAttribute("cheng", "���Ӱ༶�ɹ���");
					request.setAttribute("marketClass", marketClass);
					request.getRequestDispatcher("studentManager/shichangzylexx.jsp").forward(request, response);
				}
			} else {
				List<MarketClass> marketClass = new MarketclassDaolmpl().addclass();
				if (null != marketClass) {
					request.setAttribute("cheng", "���Ӱ༶ʧ�ܣ�");
					request.setAttribute("marketClass", marketClass);
					request.getRequestDispatcher("studentManager/shichangzylexx.jsp").forward(request, response);
				}
			}
		}
	}

	private void details(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String classId = request.getParameter("classId");
		// ����ҳ��ĳߴ�
		int pageSize = ConStant.pageSize;
		// ��ȡ����һҳ��pageIndex
		String pageIndex = request.getParameter("pageIndex");
		int currentPageNo = 1;
		if (pageIndex == null) {
			// ��һ��ҳ���ѯû��pageIndexĬ�ϸ�ֵ1
			pageIndex = "1";
		}
		// ����currentPageNo��ǰҳ��
		currentPageNo = Integer.parseInt(pageIndex);
		// ��ȡ���ܵļ�¼������ΪҪ���ݼ�¼����ȡ����ҳ��
		int totalCount = new StudentVOclassInfoDaoImpl().getStudentOVclassInfoCount(null, classId, null);
		PageSupport pages = new PageSupport();
		// ��ҳ��ߴ����pages����
		pages.setPageSize(pageSize);
		// ���ܼ�¼��set������ֵ���ڲ���װ��������ҳ��
		// ���ܼ�¼������pages����
		pages.setTotalCount(totalCount);
		// ��ȡ����ҳ��
		int totalPageCount = pages.getTotalPageCount();
		// ���ҳ��<1˵������ҳ-1���ͽ���һҳҳ�Ÿ�Ϊ155
		if (currentPageNo < 1) {
			currentPageNo = 1;
		} else if (currentPageNo > totalPageCount) {
			currentPageNo = totalPageCount;
		}
		// ����ǰҳ�Ŵ���pages����
		pages.setCurrentPageNo(currentPageNo);
		// ��ȡѧ���б���Ϣ
		// ��ȡѧ���Ͱ༶��Ϣ
		List<StudentVOclassInfo> classInfoList = new StudentVOclassInfoBizImpl().ShowstudentOVclassInfoList(null,
				classId, null, currentPageNo, pageSize);
		String info = null;
		for (int i = 0; i < classInfoList.size(); i++) {
			StudentVOclassInfo name = classInfoList.get(i);
			info = name.getClassName();
		}

		if (null != classInfoList) {
			request.setAttribute("info", info);
			request.setAttribute("classInfoList", classInfoList);
			request.getRequestDispatcher("/studentManager/shichangstudentinfo.jsp").forward(request, response);
		} else {
			request.setAttribute("ererr", "��ȡʧ�ܣ�");
			request.getRequestDispatcher("/studentManager/shichangstudentinfo.jsp").forward(request, response);
		}

	}

	private void cha(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String studyType = null;// רҵ����
		// רҵ����
		String querystudyType = request.getParameter("studyType");
		if (null != querystudyType && !"null".equals(querystudyType)) {
			studyType = querystudyType;
		}
		List<MarketClass> marketClasslist = new ArrayList<MarketClass>();
		MarketclassDao marketclassDao = new MarketclassDaolmpl();

//		List<classInfoVOmajorInfo> classVOmajorInfoList = new ArrayList<classInfoVOmajorInfo>();
//		classInfoVOmajorInfoBiz classVOmajorInfo = new classInfoVOmajorInfoBizImpl();
		// ����ҳ��ĳߴ�
		int pageSize = ConStant.pageSize;
		// ��ȡ����һҳ��pageIndex
		String pageIndex = request.getParameter("pageIndex");
		int currentPageNo = 1;
		if (pageIndex == null) {
			// ��һ��ҳ���ѯû��pageIndexĬ�ϸ�ֵ1
			pageIndex = "1";
		}
		// ����currentPageNo��ǰҳ��
		currentPageNo = Integer.parseInt(pageIndex);
		// ��ȡ���ܵļ�¼������ΪҪ���ݼ�¼����ȡ����ҳ��
//		int totalCount = new classInfoVOmajorInfoBizImpl().getclassInfoVOmajorInfoCount(studyType);
		int totalCount = new MarketclassDaolmpl().getmarketclassCount(studyType);
		PageSupport pages = new PageSupport();
		// ��ҳ��ߴ����pages����
		pages.setPageSize(pageSize);
		// ���ܼ�¼��set������ֵ���ڲ���װ��������ҳ��
		// ���ܼ�¼������pages����
		pages.setTotalCount(totalCount);
		// ��ȡ����ҳ��
		int totalPageCount = pages.getTotalPageCount();
		// ���ҳ��<1˵������ҳ-1���ͽ���һҳҳ�Ÿ�Ϊ155
		if (currentPageNo < 1) {
			currentPageNo = 1;
		} else if (currentPageNo > totalPageCount) {
			currentPageNo = totalPageCount;
		}
		// ����ǰҳ�Ŵ���pages����
		pages.setCurrentPageNo(currentPageNo);
		// ��ȡѧ���б���Ϣ
		// ��ȡѧ���Ͱ༶��Ϣ
//		classVOmajorInfoList = classVOmajorInfo.ShowclassInfoVOmajorInfoList(studyType, currentPageNo, pageSize);
		marketClasslist = marketclassDao.ShowmarterList(studyType, currentPageNo, pageSize);
		List<MarketClass> MajorList = new MarketclassDaolmpl().addclass();
		if (null != MajorList && null != marketClasslist) {
			request.setAttribute("studyType", studyType);
			request.setAttribute("majorList", MajorList);
			// �洢��ҳ����Ϣ
			request.setAttribute("pageInfo", pages);
			HttpSession session = request.getSession();
//			session.setAttribute("classAndmajorInfoList", classVOmajorInfoList);
			session.setAttribute("marketClasslist", marketClasslist);

			request.getRequestDispatcher("/studentManager/shichang.jsp").forward(request, response);
		} else {
			response.sendRedirect("main.jsp");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
