package zte.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.excel.EasyExcel;

import zte.dao.VO.marketStudentVOmarketClass.MarketStudentVOmarketClassDaoImpl;
import zte.dao.VO.studentVOclassInfo.StudentVOclassInfoDaoImpl;
import zte.entity.MarketStudent;
import zte.entity.VO.MarketStudentVOmarketClass;
import zte.entity.VO.StudentVOclassInfo;
import zte.utils.StudentEX;
import zte.utils.ShichangStudentEX;

@WebServlet("/ShichangExcelServlet")
public class ShichangExcelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String downLoadTime = sf.format(new Date());
		List<MarketStudentVOmarketClass> studentList = new MarketStudentVOmarketClassDaoImpl().getstudentInfoList();
		response.setContentType("application/vnd.ms-excel"); // excel 的响应头
		response.setCharacterEncoding("utf-8");
		String fileName = "student_" + downLoadTime + ".xlsx";
		response.setHeader("Content-disposition", "attachment;filename=" + fileName);
		EasyExcel.write(response.getOutputStream(), ShichangStudentEX.class).sheet("ѧ����Ϣ").doWrite(studentList);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
