package zte.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import zte.entity.ClassInfo;
import zte.service.classinfo.ClassInfoBiz;
import zte.service.classinfo.ClassInfoBizImpl;

@WebServlet("/getClassnamebyType.json")
public class GetClassbyTypeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		String studyType = request.getParameter("type");
		ClassInfoBiz ClassInfoBiz = new ClassInfoBizImpl();
		// ���ݿ�Ŀ�����ѯ��Ŀ��������json��ʽ����
		List<ClassInfo> ClassInfobyType = ClassInfoBiz.ShowInfo(studyType);

		String classInfo = JSON.toJSONString(ClassInfobyType);
		// ������ͻ���
		PrintWriter out = response.getWriter();
		out.print(classInfo);
		out.flush();
		out.close();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
