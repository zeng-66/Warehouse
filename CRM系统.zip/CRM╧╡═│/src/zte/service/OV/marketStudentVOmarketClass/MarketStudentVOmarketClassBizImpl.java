package zte.service.OV.marketStudentVOmarketClass;

import java.util.List;

import zte.dao.VO.marketStudentVOmarketClass.MarketStudentVOmarketClassDao;
import zte.dao.VO.marketStudentVOmarketClass.MarketStudentVOmarketClassDaoImpl;
import zte.entity.VO.MarketStudentVOmarketClass;

public class MarketStudentVOmarketClassBizImpl implements MarketStudentVOmarketClassBiz {

	MarketStudentVOmarketClassDao marketStudentVOmarketClassDao = new MarketStudentVOmarketClassDaoImpl();

	// �ܼ�¼��
	@Override
	public int getmarketStudentVOmarketClassCount(String willtrain, String className, String classType,
			String studentName) {
		return marketStudentVOmarketClassDao.getmarketStudentVOmarketClassCount(willtrain, className, classType,
				studentName);
	}

	// ��ҳ��ѯ
	@Override
	public List<MarketStudentVOmarketClass> showmarketStudentVOmarketClassList(String willtrain, String className,
			String classType, String studentName, int currentPage, int pageSize) {
		return marketStudentVOmarketClassDao.showmarketStudentVOmarketClassList(willtrain, className, classType,
				studentName, currentPage, pageSize);
	}

	// ����ѧ�Ų�ѯѧ����Ϣ
	@Override
	public MarketStudentVOmarketClass getstudentInfo(String studenteId) {
		return marketStudentVOmarketClassDao.getstudentInfo(studenteId);
	}
}
