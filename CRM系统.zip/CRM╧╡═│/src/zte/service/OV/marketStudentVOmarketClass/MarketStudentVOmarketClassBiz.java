package zte.service.OV.marketStudentVOmarketClass;

import java.util.List;

import zte.entity.VO.MarketStudentVOmarketClass;

public interface MarketStudentVOmarketClassBiz {

	/**
	 * ��ȡ�༶ѧ����Ϣ ��ҳ��ѯ
	 * 
	 * @param willtrain
	 * @param className
	 * @param classType
	 * @param studentName
	 * @param currentPage
	 * @param pageSize
	 * @return
	 */
	List<MarketStudentVOmarketClass> showmarketStudentVOmarketClassList(String willtrain, String className,
			String classType, String studentName, int currentPage, int pageSize);

	/**
	 * ҳ���ȡ�ܼ�¼�� ��ΪҪ���ܼ�¼������֪����ҳ��
	 * 
	 * @param willtrain
	 * @param className
	 * @param classType
	 * @param studentName
	 * @return
	 */
	int getmarketStudentVOmarketClassCount(String willtrain, String className, String classType, String studentName);

	/**
	 * ����ѧ�Ų�ѯѧ����Ϣ
	 * 
	 * @param studenteId
	 * @return
	 */
	MarketStudentVOmarketClass getstudentInfo(String studenteId);
}
