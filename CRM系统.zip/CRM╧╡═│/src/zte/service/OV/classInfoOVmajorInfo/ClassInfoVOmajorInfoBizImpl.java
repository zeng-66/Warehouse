package zte.service.OV.classInfoOVmajorInfo;

import java.util.List;

import zte.dao.VO.classInfoVOmajorInfo.ClassInfoVOmajorInfoDao;
import zte.dao.VO.classInfoVOmajorInfo.ClassInfoVOmajorInfoDaoImpl;
import zte.entity.VO.ClassInfoVOmajorInfo;

public class ClassInfoVOmajorInfoBizImpl implements ClassInfoVOmajorInfoBiz {
	ClassInfoVOmajorInfoDao classVOmajor = new ClassInfoVOmajorInfoDaoImpl();

	@Override
	public int getclassInfoVOmajorInfoCount(String studyType) {
		return classVOmajor.getclassInfoVOmajorInfoCount(studyType);
	}

	@Override
	public List<ClassInfoVOmajorInfo> ShowclassInfoVOmajorInfoList(String studyType, int currentPageNo, int pageSize) {
		return classVOmajor.ShowclassInfoVOmajorInfoList(studyType, currentPageNo, pageSize);
	}
}
