package zte.service.OV.studentOVclassInfo;

import java.util.List;

import zte.entity.VO.StudentVOclassInfo;

public interface StudentVOclassInfoBiz {

	/**
	 * ��ȡ�༶�Լ�ѧ����Ϣ
	 * 
	 * @param studyType
	 * @param classId
	 * @param studentName
	 * @return
	 */
	List<StudentVOclassInfo> ShowstudentOVclassInfoList(String studyType, String classId, String studentName,
			int currentPage, int pageSize);

	/**
	 * ����ѧ�Ų�ѯ��ѧ��������Ϣ
	 * 
	 * @param stuNo
	 * @return
	 */
	StudentVOclassInfo getStudentInfo(String stuNo);

	List<StudentVOclassInfo> ShowstudentOVclassInfoList(String className1, String studentName, int currentPageNo,
			int pageSize);

}
