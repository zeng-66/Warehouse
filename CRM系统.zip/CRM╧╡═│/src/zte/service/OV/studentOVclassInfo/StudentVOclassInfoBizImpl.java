package zte.service.OV.studentOVclassInfo;

import java.util.List;

import zte.dao.VO.studentVOclassInfo.StudentVOclassInfoDao;
import zte.dao.VO.studentVOclassInfo.StudentVOclassInfoDaoImpl;
import zte.entity.VO.StudentVOclassInfo;

public class StudentVOclassInfoBizImpl implements StudentVOclassInfoBiz {

	StudentVOclassInfoDao stuClassDao = new StudentVOclassInfoDaoImpl();

	@Override
	public List<StudentVOclassInfo> ShowstudentOVclassInfoList(String studyType, String classId, String studentName,
			int currentPage, int pageSize) {
		return stuClassDao.ShowstudentOVclassInfoList(studyType, classId, studentName, currentPage, pageSize);
	}

	@Override
	public StudentVOclassInfo getStudentInfo(String classId) {

		return stuClassDao.getStudentInfo(classId);
	}

	@Override
	public List<StudentVOclassInfo> ShowstudentOVclassInfoList(String className1, String studentName, int currentPageNo,
			int pageSize) {
		// TODO Auto-generated method stub
		return stuClassDao.ShowstudentOVclassInfoList(className1, studentName, currentPageNo, pageSize);
	}

}
