package zte.service.marketstudent;

import zte.entity.MarketStudent;

public interface MarketStudentBiz {

	/**
	 * ע���г�ѧ����Ϣ
	 * 
	 * @param marketstudent
	 * @return
	 */
	boolean addMarketStudent(MarketStudent marketstudent);

	/**
	 * ɾ��
	 * 
	 * @param studentId
	 * @return
	 */
	boolean delete(String studentId);

	/**
	 * �޸�
	 * 
	 * @param marketstudent
	 * @return
	 */
	public boolean updateStudentInfo(MarketStudent marketstudent);
}
