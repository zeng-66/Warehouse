package zte.service.marketstudent;

import zte.dao.marketstudent.MarketStudentDao;
import zte.dao.marketstudent.MarketStudentDaoImpl;
import zte.entity.MarketStudent;

public class MarketStudentBizImpl implements MarketStudentBiz {

	MarketStudentDao marketStudentDao = new MarketStudentDaoImpl();

	@Override
	public boolean addMarketStudent(MarketStudent marketstudent) {
		return marketStudentDao.addMarketStudent(marketstudent);
	}

	@Override
	public boolean delete(String studentId) {
		return marketStudentDao.delete(studentId);
	}

	public boolean updateStudentInfo(MarketStudent marketstudent) {
		return marketStudentDao.updateStudentInfo(marketstudent);
	}
}
