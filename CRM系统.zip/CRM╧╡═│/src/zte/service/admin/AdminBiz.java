package zte.service.admin;

import zte.entity.Admin;

public interface AdminBiz {
	
	/**
	 * ��¼
	 * @param loginCode
	 * @param password
	 * @return
	 */
	Admin login(String loginCode,String password);

}
