package zte.service.admin;

import zte.dao.admin.AdminDao;
import zte.dao.admin.AdminDaoImpl;
import zte.entity.Admin;

public class AdminBizImpl implements AdminBiz{
	
	AdminDao adminDao=new AdminDaoImpl();
	
	@Override
	public Admin login(String loginCode, String password) {
		return adminDao.login(loginCode, password);
	}

}
