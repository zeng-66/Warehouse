package zte.service.student;

import zte.dao.student.StudentDao;
import zte.dao.student.StudentDaoImpl;
import zte.entity.Student;

public class StudentBizImpl implements StudentBiz {
	StudentDao studentDao = new StudentDaoImpl();

	@Override
	public boolean AddStudent(Student student) {
		return studentDao.AddStudent(student);
	}

	@Override
	public boolean delete(String stuNo) {
		return studentDao.delete(stuNo);
	}

	@Override
	public boolean updateStudentInfo(Student student) {
		return studentDao.updateStudentInfo(student);
	}

}
