package zte.service.classinfo;

import java.util.List;

import zte.dao.classInfo.ClassInfoDao;
import zte.dao.classInfo.ClassInfoDaoImpl;
import zte.entity.ClassInfo;

public class ClassInfoBizImpl implements ClassInfoBiz {

	ClassInfoDao classInfoDao = new ClassInfoDaoImpl();

	@Override
	public List<ClassInfo> ShowInfo() {
		return classInfoDao.ShowInfo();
	}

	@Override
	public List<ClassInfo> ShowInfo(String studyType) {
		return classInfoDao.ShowInfo(studyType);
	}

	@Override
	public boolean addClass(ClassInfo classInfo) {
		return classInfoDao.addClass(classInfo);
	}

	@Override
	public boolean updateClassInfo(ClassInfo classInfo) {
		return classInfoDao.updateClassInfo(classInfo);
	}

	@Override
	public boolean pdClass(String stuNo) {
		return classInfoDao.pdClass(stuNo);
	}

	@Override
	public boolean delete(String classId) {
		return classInfoDao.delete(classId);
	}

}
