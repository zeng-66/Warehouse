package zte.service.major;

import java.util.List;

import zte.dao.major.MajorDao;
import zte.dao.major.MajorDaoImpl;
import zte.entity.Major;

public class MajorBizImpl implements MajorBiz {
	MajorDao majorDao = new MajorDaoImpl();

	@Override
	public List<Major> ShowInfo() {
		return majorDao.ShowInfo();
	}

}
