package zte.service.major;

import java.util.List;

import zte.entity.Major;

public interface MajorBiz {

	/**
	 * ��ѯ����רҵ��Ϣ
	 * 
	 * @return
	 */
	List<Major> ShowInfo();
}
