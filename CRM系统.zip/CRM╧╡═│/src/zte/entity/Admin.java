package zte.entity;

/**
 * ����Ա�û�
 * 
 * @author Administrator
 *
 */
public class Admin {

	private int id;// ���ID
	private String logincode;// ��¼�˺�
	private int roleId;// ��ɫ
	private String password;// ����
	private String createTime;// ����ʱ��

	public Admin() {
	}

	public Admin(int id, String logincode, int roleId, String password, String createTime) {
		super();
		this.id = id;
		this.logincode = logincode;
		this.roleId = roleId;
		this.password = password;
		this.createTime = createTime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLogincode() {
		return logincode;
	}

	public void setLogincode(String logincode) {
		this.logincode = logincode;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

}
