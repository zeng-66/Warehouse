package zte.entity;

public class ZteCheckJob {

	private String studentId;// ѧ��
	private String ckTime;// ����
	private String ckstatu;// ��ҵ״̬��δ��ɡ��һ�㡢�á��ǳ���

	public ZteCheckJob(String studentId, String ckTime, String ckstatu) {
		super();
		this.studentId = studentId;
		this.ckTime = ckTime;
		this.ckstatu = ckstatu;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getCkTime() {
		return ckTime;
	}

	public void setCkTime(String ckTime) {
		this.ckTime = ckTime;
	}

	public String getCkstatu() {
		return ckstatu;
	}

	public void setCkstatu(String ckstatu) {
		this.ckstatu = ckstatu;
	}

}
