package zte.entity;

public class Student {

	private String studentid;// ѧ��id
	private String studentName;// ѧ������
	private String classId;// �༶id
	private String fromSchool;// ����ѧУ
	private String education; // ѧ��
	private String loginCode; // ��¼�˺�
	private String password; // ��¼����

	public Student() {
	}

	public Student(String studentid, String classId, String studentName, String fromSchool, String education,
			String loginCode, String password) {
		super();
		this.studentid = studentid;
		this.studentName = studentName;
		this.classId = classId;
		this.fromSchool = fromSchool;
		this.education = education;
		this.loginCode = loginCode;
		this.password = password;
	}

	public String getStudentid() {
		return studentid;
	}

	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getFromSchool() {
		return fromSchool;
	}

	public void setFromSchool(String fromSchool) {
		this.fromSchool = fromSchool;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getLoginCode() {
		return loginCode;
	}

	public void setLoginCode(String loginCode) {
		this.loginCode = loginCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
