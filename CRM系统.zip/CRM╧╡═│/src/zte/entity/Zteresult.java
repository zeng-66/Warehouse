package zte.entity;

public class Zteresult {
	private String studentid;// ѧ��
	private String examdate;// ����
	private String examType;// 1�տ� 2 �ܿ� 3�׶ο� 4 ��Ŀ���
	private String studentresult;// �ɼ�

	public Zteresult(String studentid, String examdate, String examType, String studentresult) {
		super();
		this.studentid = studentid;
		this.examdate = examdate;
		this.examType = examType;
		this.studentresult = studentresult;
	}

	public String getStudentid() {
		return studentid;
	}

	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}

	public String getExamdate() {
		return examdate;
	}

	public void setExamdate(String examdate) {
		this.examdate = examdate;
	}

	public String getExamType() {
		return examType;
	}

	public void setExamType(String examType) {
		this.examType = examType;
	}

	public String getStudentresult() {
		return studentresult;
	}

	public void setStudentresult(String studentresult) {
		this.studentresult = studentresult;
	}

}
