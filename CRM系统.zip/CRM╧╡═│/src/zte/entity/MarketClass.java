package zte.entity;

public class MarketClass {

	private String mkClassId;// �༶��
	private String className;// �༶����
	private String classType;// ��У��ѵ��Ӫ

	public MarketClass(String mkClassId, String className, String classType) {
		super();
		this.mkClassId = mkClassId;
		this.className = className;
		this.classType = classType;
	}

	public MarketClass(String classType) {
		super();
		this.classType = classType;
	}

	public String getMkClassId() {
		return mkClassId;
	}

	public void setMkClassId(String mkClassId) {
		this.mkClassId = mkClassId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

}
