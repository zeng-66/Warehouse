package zte.entity;

public class MarketStudent {

	private String studentId;// ���
	private String studentName;// ѧ������
	private String mkClassId; // ����marketClass��ID
	private String fromschool;// ����ѧУ
	private String education;// ѧ�� 1���� 2 ��ר
	private String phone;// �绰
	private String qq;// QQ
	private String xinge;// 1 �������˸� 2�������˸� 3 �䵭��
	private String beizhu; // ��ע���
	private String willtrain;// 0 ��ȷ�� 1ȷ����ѵ 2 ȷ������ѵ
	private String createTime;// �������ݴ���ʱ��
	private String createauthorID;// ������ --����zteadminID
	private String modifyauthor;// �޸�������
	private String modifyauthorTime;// �޸�ʱ��

	public MarketStudent(String studentId, String studentName, String mkClassId, String fromschool, String education,
			String phone, String qq, String xinge, String beizhu, String willtrain, String modifyauthor,
			String modifyauthorTime) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.mkClassId = mkClassId;
		this.fromschool = fromschool;
		this.education = education;
		this.phone = phone;
		this.qq = qq;
		this.xinge = xinge;
		this.beizhu = beizhu;
		this.willtrain = willtrain;
		this.modifyauthor = modifyauthor;
		this.modifyauthorTime = modifyauthorTime;
	}

	public MarketStudent() {
	}

	public MarketStudent(String studentId, String studentName, String mkClassId, String fromschool, String education,
			String phone, String qq, String xinge, String beizhu, String willtrain, String createTime,
			String createauthorID, String modifyauthor, String modifyauthorTime) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.mkClassId = mkClassId;
		this.fromschool = fromschool;
		this.education = education;
		this.phone = phone;
		this.qq = qq;
		this.xinge = xinge;
		this.beizhu = beizhu;
		this.willtrain = willtrain;
		this.createTime = createTime;
		this.createauthorID = createauthorID;
		this.modifyauthor = modifyauthor;
		this.modifyauthorTime = modifyauthorTime;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getMkClassId() {
		return mkClassId;
	}

	public void setMkClassId(String mkClassId) {
		this.mkClassId = mkClassId;
	}

	public String getFromschool() {
		return fromschool;
	}

	public void setFromschool(String fromschool) {
		this.fromschool = fromschool;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getXinge() {
		return xinge;
	}

	public void setXinge(String xinge) {
		this.xinge = xinge;
	}

	public String getBeizhu() {
		return beizhu;
	}

	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}

	public String getWilltrain() {
		return willtrain;
	}

	public void setWilltrain(String willtrain) {
		this.willtrain = willtrain;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getCreateauthorID() {
		if (createauthorID.equals("1")) {
			createauthorID = "admin";
		}
		return createauthorID;
	}

	public void setCreateauthorID(String createauthorID) {
		this.createauthorID = createauthorID;
	}

	public String getModifyauthor() {

		return modifyauthor;
	}

	public void setModifyauthor(String modifyauthor) {
		this.modifyauthor = modifyauthor;
	}

	public String getModifyauthorTime() {
		return modifyauthorTime;
	}

	public void setModifyauthorTime(String modifyauthorTime) {
		this.modifyauthorTime = modifyauthorTime;
	}

}
