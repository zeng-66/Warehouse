package zte.entity;

/**
 * רҵ��Ϣ
 * 
 * @author zeng
 *
 */
public class Major {

	private int id; // ѧϰרҵid
	private String major; // ѧϰרҵ

	public Major() {
	}

	public Major(int id, String major) {
		super();
		this.id = id;
		this.major = major;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

}
