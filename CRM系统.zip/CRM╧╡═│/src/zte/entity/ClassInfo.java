package zte.entity;

/**
 * �༶��Ϣ
 * 
 * @author zeng
 *
 */
public class ClassInfo {
	private int classId;// �༶id
	private String classname;// �༶����
	private int classType;// �༶����

	public ClassInfo() {
	}

	public ClassInfo(int classId, String className, int classType) {
		super();
		this.classId = classId;
		this.classname = className;
		this.classType = classType;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public String getClassName() {
		return classname;
	}

	public void setClassName(String className) {
		this.classname = className;
	}

	public int getClassType() {
		return classType;
	}

	public void setClassType(int classType) {
		this.classType = classType;
	}

}
