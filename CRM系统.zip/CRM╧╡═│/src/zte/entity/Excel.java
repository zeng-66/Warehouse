package zte.entity;

public class Excel {
	private String studentid;// ѧ��
	private String studentname;// ����
	private String examdate;// ����
	private String studentresult;// �ɼ�

	public Excel(String studentid, String studentname, String examdate, String studentresult) {
		super();
		this.studentid = studentid;
		this.studentname = studentname;
		this.examdate = examdate;
		this.studentresult = studentresult;
	}

	public Excel(String studentid, String studentname, String studentresult) {
		super();
		this.studentid = studentid;
		this.studentname = studentname;
		this.studentresult = studentresult;
	}

	public Excel(String examdate, String studentresult) {
		super();
		this.examdate = examdate;
		this.studentresult = studentresult;
	}

	public Excel(String studentid) {
		super();
		this.studentid = studentid;
	}

	public String getStudentid() {
		return studentid;
	}

	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

	public String getExamdate() {
		return examdate;
	}

	public void setExamdate(String examdate) {
		this.examdate = examdate;
	}

	public String getStudentresult() {
		return studentresult;
	}

	public void setStudentresult(String studentresult) {
		this.studentresult = studentresult;
	}

}
