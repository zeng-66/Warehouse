package zte.entity.VO;

/**
 * --��ҵ������ͳ�Ʋ�ѯ
 * 
 * @author zeng
 *
 */
public class StudentVOcheckjobInfo {

	private String id;// ����Id
	private String studentName;// ѧ������
	private String cktime;// ��ҵ�����������
	private String ckstatu;// ��ҵ������

	public StudentVOcheckjobInfo(String id, String cktime, String ckstatu) {
		super();
		this.id = id;
		this.cktime = cktime;
		this.ckstatu = ckstatu;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getCktime() {
		return cktime;
	}

	public void setCktime(String cktime) {
		this.cktime = cktime;
	}

	public String getCkstatu() {
		return ckstatu;
	}

	public void setCkstatu(String ckstatu) {
		this.ckstatu = ckstatu;
	}

	public StudentVOcheckjobInfo() {
	}

	public StudentVOcheckjobInfo(String id, String studentName, String cktime, String ckstatu) {
		super();
		this.id = id;
		this.studentName = studentName;
		this.cktime = cktime;
		this.ckstatu = ckstatu;
	}

}
