package zte.entity.VO;

public class StudnetVOresultInfo {
	private String id;// ����ID
	private String studentName;// ѧ������
	private String examdate;// ��������
	private String examtype;// ��������
	private String studentresult;// ���Գɼ�

	public StudnetVOresultInfo() {
	}

	public StudnetVOresultInfo(String id, String examdate, String studentresult) {
		super();
		this.id = id;
		this.examdate = examdate;
		this.studentresult = studentresult;
	}

	public StudnetVOresultInfo(String id, String studentName, String examdate, String examtype, String studentresult) {
		super();
		this.id = id;
		this.studentName = studentName;
		this.examdate = examdate;
		this.examtype = examtype;
		this.studentresult = studentresult;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getExamdate() {

		return examdate;
	}

	public void setExamdate(String examdate) {
		this.examdate = examdate;

	}

	public String getExamtype() {
		if (examtype.equals("1")) {
			examtype = "����";
		}
		if (examtype.equals("2")) {
			examtype = "�ܿ�";
		}
		return examtype;

	}

	public void setExamtype(String examtype) {
		this.examtype = examtype;
	}

	public String getStudentresult() {
		return studentresult;
	}

	public void setStudentresult(String studentresult) {
		this.studentresult = studentresult;
	}

}
