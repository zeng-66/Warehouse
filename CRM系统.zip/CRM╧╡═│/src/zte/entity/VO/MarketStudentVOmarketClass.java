package zte.entity.VO;

public class MarketStudentVOmarketClass {

	private String studentId;// ���
	private String studentName;// ѧ������
	private String mkClassId; // ����marketClass��ID
	private String fromSchool;// ����ѧУ
	private String education;// ѧ�� 1���� 2 ��ר
	private String phone;// �绰
	private String qq;// QQ
	private String xinge;// 1 �������˸� 2�������˸� 3 �䵭��
	private String beizhu; // ��ע���
	private String willTrain;// 0 ��ȷ�� 1ȷ����ѵ 2 ȷ������ѵ ����
	private String createTime;// �������ݴ���ʱ��
	private String createauthorID;// ������ --����zteadminID
	private String modifyauthor;// �޸�������
	private String modifyauthorTime;// �޸�ʱ��

	private String className;// �༶����
	private String classType;// ��У��ѵ��Ӫ

	private String roleId;// ��ɫID
	private String loginCode;// ��¼�˺�

	public MarketStudentVOmarketClass(String studentId, String studentName, String mkClassId, String fromSchool,
			String education, String phone, String qq, String xinge, String beizhu, String willTrain, String createTime,
			String createauthorID, String modifyauthor, String modifyauthorTime, String className, String classType,
			String roleId, String loginCode) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.mkClassId = mkClassId;
		this.fromSchool = fromSchool;
		this.education = education;
		this.phone = phone;
		this.qq = qq;
		this.xinge = xinge;
		this.beizhu = beizhu;
		this.willTrain = willTrain;
		this.createTime = createTime;
		this.createauthorID = createauthorID;
		this.modifyauthor = modifyauthor;
		this.modifyauthorTime = modifyauthorTime;
		this.className = className;
		this.classType = classType;
		this.roleId = roleId;
		this.loginCode = loginCode;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getMkClassId() {
		return mkClassId;
	}

	public void setMkClassId(String mkClassId) {
		this.mkClassId = mkClassId;
	}

	public String getFromSchool() {
		return fromSchool;
	}

	public void setFromSchool(String fromSchool) {
		this.fromSchool = fromSchool;
	}

	public String getEducation() {
		if (education.equals("1")) {
			education = "����";
		} else if (education.equals("2")) {
			education = "��ר";
		} else if (education.equals("3")) {
			education = "����";
		}
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getXinge() {
		if (xinge.equals("1")) {
			xinge = "������";
		} else if (xinge.equals("2")) {
			xinge = "������";
		} else if (xinge.equals("3")) {
			xinge = "�䵭��";
		}
		return xinge;
	}

	public void setXinge(String xinge) {
		this.xinge = xinge;
	}

	public String getBeizhu() {
		return beizhu;
	}

	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}

	public String getWillTrain() {
		if (willTrain.equals("0")) {
			willTrain = "��ȷ��";
		} else if (willTrain.equals("1")) {
			willTrain = "������";
		} else if (willTrain.equals("2")) {
			willTrain = "ȷ����ѵ";
		} else if (willTrain.equals("3")) {
			willTrain = "û����ѵ����";
		}
		return willTrain;
	}

	public void setWillTrain(String willTrain) {
		this.willTrain = willTrain;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getCreateauthorID() {
		if (createauthorID.equals("1")) {
			createauthorID = "admin";
		}
		return createauthorID;
	}

	public void setCreateauthorID(String createauthorID) {
		this.createauthorID = createauthorID;
	}

	public String getModifyauthor() {
		if (modifyauthor == null) {
			return modifyauthor;
		} else if (modifyauthor.equals("1")) {
			modifyauthor = "admin";
		}
		return modifyauthor;
	}

	public void setModifyauthor(String modifyauthor) {
		this.modifyauthor = modifyauthor;
	}

	public String getModifyauthorTime() {
		return modifyauthorTime;
	}

	public void setModifyauthorTime(String modifyauthorTime) {
		this.modifyauthorTime = modifyauthorTime;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getClassType() {

		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getLoginCode() {
		return loginCode;
	}

	public void setLoginCode(String loginCode) {
		this.loginCode = loginCode;
	}

}
