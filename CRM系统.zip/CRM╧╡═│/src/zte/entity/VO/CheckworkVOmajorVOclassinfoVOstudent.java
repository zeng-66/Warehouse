package zte.entity.VO;

public class CheckworkVOmajorVOclassinfoVOstudent {

	private String id; // רҵID
	private String major; // רҵ����
	private String classId;// �༶Id
	private String className; // �༶����
	private String studyType; // �༶����
	private String studentId;// ѧ��
	private String studentName;// ����
	private String fromSchool;// ����ѧУ
	private String education;// ѧ��
	private String loginCode;// ��¼�˺�
	private String password;// ����
	private String ckTime;// ����
	private String ckStatu;// --����״̬���ٵ������ˡ�����

	public CheckworkVOmajorVOclassinfoVOstudent(String id, String major, String classId, String className,
			String studyType, String studentId, String studentName, String fromSchool, String education,
			String loginCode, String password, String ckTime, String ckStatu) {
		super();
		this.id = id;
		this.major = major;
		this.classId = classId;
		this.className = className;
		this.studyType = studyType;
		this.studentId = studentId;
		this.studentName = studentName;
		this.fromSchool = fromSchool;
		this.education = education;
		this.loginCode = loginCode;
		this.password = password;
		this.ckTime = ckTime;
		this.ckStatu = ckStatu;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getStudyType() {
		return studyType;
	}

	public void setStudyType(String studyType) {
		this.studyType = studyType;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getFromSchool() {
		return fromSchool;
	}

	public void setFromSchool(String fromSchool) {
		this.fromSchool = fromSchool;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getLoginCode() {
		return loginCode;
	}

	public void setLoginCode(String loginCode) {
		this.loginCode = loginCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCkTime() {
		return ckTime;
	}

	public void setCkTime(String ckTime) {
		this.ckTime = ckTime;
	}

	public String getCkStatu() {
		return ckStatu;
	}

	public void setCkStatu(String ckStatu) {
		this.ckStatu = ckStatu;
	}

}
