package zte.entity.VO;

public class ClassinfoVOmajoorinfoVOstudentinfo {
	private String id; // רҵID
	private String major; // רҵ����
	private String classId;// �༶Id
	private String className; // �༶����
	private String studytype; // �༶����
	private String studentId;// ѧ��
	private String studentName;// ����
	private String fromSchool;// ����ѧУ
	private String education;// ѧ��
	private String loginCode;// ��¼�˺�
	private String password;// ����
	private String examdate;// ����
	private String examType;// 1�տ� 2 �ܿ� 3�׶ο� 4 ��Ŀ���
	private String studentresult;// �ɼ�

	public ClassinfoVOmajoorinfoVOstudentinfo(String id, String major, String classId, String className,
			String studytype, String studentId, String studentName, String fromSchool, String education,
			String loginCode, String password, String examdate, String examType, String studentresult) {
		super();
		this.id = id;
		this.major = major;
		this.classId = classId;
		this.className = className;
		this.studytype = studytype;
		this.studentId = studentId;
		this.studentName = studentName;
		this.fromSchool = fromSchool;
		this.education = education;
		this.loginCode = loginCode;
		this.password = password;
		this.examdate = examdate;
		this.examType = examType;
		this.studentresult = studentresult;
	}

	public String getExamdate() {
		return examdate;
	}

	public void setExamdate(String examdate) {
		this.examdate = examdate;
	}

	public String getExamType() {
		return examType;
	}

	public void setExamType(String examType) {
		this.examType = examType;
	}

	public String getStudentresult() {
		return studentresult;
	}

	public void setStudentresult(String studentresult) {
		this.studentresult = studentresult;
	}

	public ClassinfoVOmajoorinfoVOstudentinfo(String id, String classId, String className, String studytype,
			String studentId, String studentName, String fromSchool, String education, String loginCode,
			String password) {
		super();
		this.id = id;
		this.classId = classId;
		this.className = className;
		this.studytype = studytype;
		this.studentId = studentId;
		this.studentName = studentName;
		this.fromSchool = fromSchool;
		this.education = education;
		this.loginCode = loginCode;
		this.password = password;
	}

	public ClassinfoVOmajoorinfoVOstudentinfo(String id, String major, String classId, String className,
			String studytype, String studentId, String studentName, String fromSchool, String education,
			String loginCode, String password) {
		super();
		this.id = id;
		this.major = major;
		this.classId = classId;
		this.className = className;
		this.studytype = studytype;
		this.studentId = studentId;
		this.studentName = studentName;
		this.fromSchool = fromSchool;
		this.education = education;
		this.loginCode = loginCode;
		this.password = password;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getStudytype() {
		return studytype;
	}

	public void setStudytype(String studytype) {
		this.studytype = studytype;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getFromSchool() {
		return fromSchool;
	}

	public void setFromSchool(String fromSchool) {
		this.fromSchool = fromSchool;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getLoginCode() {
		return loginCode;
	}

	public void setLoginCode(String loginCode) {
		this.loginCode = loginCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
