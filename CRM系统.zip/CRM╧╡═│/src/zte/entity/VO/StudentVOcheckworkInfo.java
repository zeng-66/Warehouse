package zte.entity.VO;

/**
 * ���ڹ�����ѯ
 * 
 * @author zeng
 *
 */
public class StudentVOcheckworkInfo {
	private String id;// ����Id
	private String studentName;// ѧ������
	private String cktime;// ��������
	private String ckstatu;// ����״̬
	private String classId;// �༶ID
	private String classname;//// �༶����
	private String studentId;//// ѧ��

	public StudentVOcheckworkInfo(String id, String studentName, String cktime, String ckstatu, String classId,
			String classname, String studentId) {
		super();
		this.id = id;
		this.studentName = studentName;
		this.cktime = cktime;
		this.ckstatu = ckstatu;
		this.classId = classId;
		this.classname = classname;
		this.studentId = studentId;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public StudentVOcheckworkInfo() {
	}

	public StudentVOcheckworkInfo(String id, String studentName, String cktime, String ckstatu, String classId) {
		super();
		this.id = id;
		this.studentName = studentName;
		this.cktime = cktime;
		this.ckstatu = ckstatu;
		this.classId = classId;
	}

	public StudentVOcheckworkInfo(String id, String studentName, String cktime, String ckstatu, String classId,
			String classname) {
		super();
		this.id = id;
		this.studentName = studentName;
		this.cktime = cktime;
		this.ckstatu = ckstatu;
		this.classId = classId;
		this.classname = classname;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getCktime() {
		return cktime;
	}

	public void setCktime(String cktime) {
		this.cktime = cktime;
	}

	public String getCkstatu() {
		return ckstatu;
	}

	public void setCkstatu(String ckstatu) {
		this.ckstatu = ckstatu;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}

}
