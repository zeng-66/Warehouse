package zte.entity.VO;

/**
 * ѧ������ҳ��
 * 
 * @author zeng
 *
 */
public class StudentVOclassInfo {
	private String studentId;// ѧ��
	private String studentName;// ����
	private String classId;// �༶ID
	private String fromSchool;// ����ѧУ
	private String education;// ѧ��
	private String loginCode;// ��¼�˺�
	private String password;// ����
	private String className;// �༶����
	private String studyType;// �༶����

	public StudentVOclassInfo() {
	}

	public StudentVOclassInfo(String studentId, String studentName, String fromSchool, String education,
			String loginCode, String password, String className, String studyType) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.fromSchool = fromSchool;
		this.education = education;
		this.loginCode = loginCode;
		this.password = password;
		this.className = className;
		this.studyType = studyType;
	}

	public StudentVOclassInfo(String studentId, String studentName, String classId, String fromSchool, String education,
			String studyType) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.classId = classId;
		this.fromSchool = fromSchool;
		this.education = education;
		this.studyType = studyType;
	}

	public StudentVOclassInfo(String studentId, String studentName, String classId, String fromSchool, String education,
			String loginCode, String password, String className, String studyType) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.classId = classId;
		this.fromSchool = fromSchool;
		this.education = education;
		this.loginCode = loginCode;
		this.password = password;
		this.className = className;
		this.studyType = studyType;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getFromSchool() {
		return fromSchool;
	}

	public void setFromSchool(String fromSchool) {
		this.fromSchool = fromSchool;
	}

	public String getEducation() {
		if (education.equals("1")) {
			education = "����";
		} else if (education.equals("2")) {
			education = "ר��";
		}
		return education;
	}

	public void setEducation(String education) {

		this.education = education;
	}

	public String getLoginCode() {
		return loginCode;
	}

	public void setLoginCode(String loginCode) {
		this.loginCode = loginCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getStudyType() {
		if (studyType.equals("1")) {
			studyType = "Java";
		} else if (studyType.equals("2")) {
			studyType = "Web";
		} else if (studyType.equals("3")) {
			studyType = "UI";
		}
		return studyType;
	}

	public void setStudyType(String studyType) {
		this.studyType = studyType;
	}

}
