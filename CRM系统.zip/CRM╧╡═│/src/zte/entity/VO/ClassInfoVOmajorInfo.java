package zte.entity.VO;

public class ClassInfoVOmajorInfo {

	private String id; // רҵID
	private String major; // רҵ����
	private String classId;// �༶Id
	private String className; // �༶����
	private String studytype; // �༶����

	public ClassInfoVOmajorInfo() {
	}

	public ClassInfoVOmajorInfo(String classId, String className, String studytype, String major) {
		super();
		this.major = major;
		this.classId = classId;
		this.className = className;
		this.studytype = studytype;
	}

	public ClassInfoVOmajorInfo(String classId, String className, String id, String major, String studytype) {
		super();
		this.id = id;
		this.major = major;
		this.classId = classId;
		this.className = className;
		this.studytype = studytype;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getStudytype() {
		return studytype;
	}

	public void setStudytype(String studytype) {
		this.studytype = studytype;
	}

}
