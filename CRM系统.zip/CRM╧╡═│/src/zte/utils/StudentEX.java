package zte.utils;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;

/**
 * ���ñ�ͷ��Ϣ
 * 
 * @author Administrator
 *
 */
@ContentRowHeight(30) // ����cell�߶�Ϊ50
@HeadRowHeight(40) // ���ñ�ͷ �߶�Ϊ40
public class StudentEX {
	@ExcelProperty(value = "ѧ��", index = 0)
	private String studentId;// ����
	@ExcelProperty(value = "����", index = 1)
	private String studentName;// ����
	@ColumnWidth(15)
	@ExcelProperty(value = "�༶id", index = 2)
	private String classId;// �༶
	@ExcelProperty(value = "ѧУ", index = 3)
	private String fromSchool;// ѧУ
	@ExcelProperty(value = "ѧ��", index = 4)
	private String education;// ѧ��
	@ExcelProperty(value = "�˺�", index = 5)
	private String loginCode;// �˺�
	@ColumnWidth(15)
	@ExcelProperty(value = "����", index = 6)
	private String password;// ����
	@ColumnWidth(15)
	@ExcelProperty(value = "�༶����", index = 7)
	private String className;// �༶
	@ColumnWidth(15)
	@ExcelProperty(value = "�༶����", index = 8)
	private String studyType;// �༶����

	public StudentEX() {
	}

	public StudentEX(String studentId, String studentName, String classId, String fromSchool, String education,
			String loginCode, String password, String className, String studyType) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.classId = classId;
		this.fromSchool = fromSchool;
		this.education = education;
		this.loginCode = loginCode;
		this.password = password;
		this.className = className;
		this.studyType = studyType;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getFromSchool() {
		return fromSchool;
	}

	public void setFromSchool(String fromSchool) {
		this.fromSchool = fromSchool;
	}

	public String getEducation() {

		return education;
	}

	public void setEducation(String education) {

		this.education = education;
	}

	public String getLoginCode() {
		return loginCode;
	}

	public void setLoginCode(String loginCode) {
		this.loginCode = loginCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getStudyType() {
		return studyType;
	}

	public void setStudyType(String studyType) {
		this.studyType = studyType;
	}

}
