package zte.utils;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;

@ContentRowHeight(30) // ����cell�߶�Ϊ50
@HeadRowHeight(40) // ���ñ�ͷ �߶�Ϊ40
public class CheckVoEX {
	@ColumnWidth(15)
	@ExcelProperty(value = "����id", index = 0)
	private String id;// ����id;
	@ExcelProperty(value = "����", index = 1)
	private String studentName;// ѧ������;
	@ColumnWidth(15)
	@ExcelProperty(value = "����ʱ��", index = 2)
	private String ckTime;// ����ʱ��
	@ColumnWidth(15)
	@ExcelProperty(value = "����״̬", index = 3)
	String ckstatu;// ����״̬

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getCkTime() {
		return ckTime;
	}

	public void setCkTime(String ckTime) {
		this.ckTime = ckTime;
	}

	public String getCkstatu() {
		return ckstatu;
	}

	public void setCkstatu(String ckstatu) {
		this.ckstatu = ckstatu;
	}

	public CheckVoEX(String id, String studentName, String ckTime, String ckstatu) {
		super();
		this.id = id;
		this.studentName = studentName;
		this.ckTime = ckTime;
		this.ckstatu = ckstatu;
	}

	public CheckVoEX() {
		super();
		// TODO Auto-generated constructor stub
	}

}
