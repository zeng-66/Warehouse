package zte.dao.excel;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import zte.dao.BaseDao;
import zte.utils.CheckVoEX;

public class KaoQinEXImpDao extends BaseDao implements KaoQinExDao {

	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Connection conn = null;

	@Override
	public int getCheckVoCount(String majorid, String classid, String stuName, String checkDate, String checkStatu) {
		int count = 0;
		String sql = "select * from ztestudent s inner join zteclassinfo c on s.classid=c.classid inner join ztecheckwork w on s.studentid=w.studentno where 1=1 ";
		if (majorid != null && !"".equals(majorid)) {
			sql = sql + " and c.studytype= " + majorid;
		}
		if (classid != null && !"".equals(classid)) {
			sql = sql + " and s.classid= " + classid;
		}
		if (stuName != null && !"".equals(stuName)) {
			sql = sql + " and s.studentname like '%" + stuName + "%'";
		}
		if (checkDate != null && !"".equals(checkDate)) {
			sql = sql + " and w.cktime=to_date('" + checkDate + "', 'yyyy-MM-dd')";
		}
		if (checkStatu != null && !"".equals(checkStatu)) {
			sql = sql + " and w.ckstatu=" + checkStatu;
		}
		Connection conn = this.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				count++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeAll(conn, pstmt, rs);
		}
		return count;

	}

	@Override
	public List<CheckVoEX> getCheckVoList(int curpage, int size, String majorid, String classid, String stuName,
			String checkDate, String checkStatu) {
		List<CheckVoEX> list = new ArrayList<CheckVoEX>();

		String secondsql = " select w.id,s.studentname,w.cktime,w.ckstatu,c.classid,c.studytype from ztestudent s inner join zteclassinfo c on s.classid=c.classid inner join ztecheckwork w on s.studentid=w.studentno where 1=1";
		if (majorid != null && !"".equals(majorid)) {
			secondsql = secondsql + " and c.studytype= " + majorid;
		}
		if (classid != null && !"".equals(classid)) {
			secondsql = secondsql + " and c.classid= " + classid;
		}
		if (stuName != null && !"".equals(stuName)) {
			secondsql = secondsql + " and s.studentname like '%" + stuName + "%'";
		}
		if (checkDate != null && !"".equals(checkDate)) {
			secondsql = secondsql + " and w.cktime=to_date('" + checkDate + "', 'yyyy-mm-dd')";
		}
		if (checkStatu != null && !"".equals(checkStatu)) {
			secondsql = secondsql + " and w.ckstatu=" + checkStatu;
		}

		String sql = secondsql;
		try {
			conn = super.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String id = rs.getString("id");
				String studentName = rs.getString("studentname");
				String ckTimeF = rs.getString("cktime");
				String[] ckTimes = ckTimeF.split(" ");
				String ckTime = ckTimes[0];
				String ckstatuid2 = rs.getString("ckstatu");
				String ckstatuid = "";
				switch (ckstatuid2) {
				case "1":
					ckstatuid = "����";
					break;
				case "2":
					ckstatuid = "�ٵ�";
					break;
				case "3":
					ckstatuid = "����";
					break;
				case "4":
					ckstatuid = "����";
					break;
				default:

					break;
				}
				CheckVoEX checkVo = new CheckVoEX(id, studentName, ckTime, ckstatuid);
				list.add(checkVo);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeAll(conn, pstmt, rs);
		}

		return list;

	}

}
