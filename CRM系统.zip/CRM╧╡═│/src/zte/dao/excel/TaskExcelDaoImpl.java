package zte.dao.excel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import zte.dao.BaseDao;
import zte.entity.Excel;
import zte.entity.VO.StudentVOclassInfo;

public class TaskExcelDaoImpl extends BaseDao implements TaskExcelDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	/**
	 * ���ݰ༶ ѧ�������ҵ���ѧ������µ����м�¼ ����ȡ�ð����в���ĳ�������
	 */
	@Override
	public List<Excel> getTask(int studentids, String data, int classid) {
		conn = this.getConnection();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<Excel> excelList = new ArrayList<Excel>();
		conn = this.getConnection();
		String sql = "select DISTINCT z.ckTime,r.ckstatu\r\n" + "from ztecheckjob z\r\n"
				+ "INNER JOIN ztestudent s on s.studentid=z.studentNo\r\n"
				+ "INNER JOIN zteclassInfo c on c.CLASSID = s.classid\r\n" + "LEFT JOIN(\r\n"
				+ "select DISTINCT z.ckTime,z.ckstatu\r\n" + "from ztecheckjob z\r\n"
				+ "INNER JOIN ztestudent s on s.studentid=z.studentNo\r\n"
				+ "INNER JOIN zteclassInfo c on c.CLASSID = s.classid\r\n" + "where z.studentNo=?\r\n"
				+ "and c.classid=?\r\n" + "and (to_char(z.ckTime,'yyyy-MM-dd hh24:mi:ss') LIKE ?)\r\n"
				+ "ORDER BY ckTime \r\n" + ") r on z.ckTime=r.ckTime\r\n" + "where c.classid=?\r\n"
				+ "and (to_char(z.ckTime,'yyyy-MM-dd hh24:mi:ss') LIKE ?)\r\n" + "ORDER BY ckTime";

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, studentids);
			pstmt.setInt(2, classid);
			pstmt.setString(3, data);

			pstmt.setInt(4, classid);
			pstmt.setString(5, data);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String examdate = sdf.format(rs.getTimestamp("ckTime"));
				String studentresult = rs.getString("ckstatu");
				// �����ݷ�װ����������ȥ
				Excel excel = new Excel(examdate, studentresult);
				excelList.add(excel);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return excelList;
	}

	/**
	 * ͨ������İ༶���ڲ����Ҫ���ѧ������ �Դ˾�������������
	 */
	@Override
	public List<Excel> getcount(String data, int classid) {
		conn = this.getConnection();
		List<Excel> excelList = new ArrayList<Excel>();
		String sql = "select  DISTINCT z.STUDENTno from ztecheckjob z INNER JOIN ztestudent s on s.studentid=z.studentno INNER JOIN zteclassInfo c on c.CLASSID = s.classid where c.classid=? and (to_char(z.ckTime,'yyyy-MM-dd hh24:mi:ss') LIKE ?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, classid);
			pstmt.setString(2, data);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String examtype = rs.getString("studentno");
				Excel excel = new Excel(examtype);
				excelList.add(excel);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return excelList;
	}

	// ��ȡѧ�ź�����
	@Override
	public List<Excel> getTasks(int studentids, int classid) {
		List<Excel> excelList = new ArrayList<Excel>();
		String sql = "select DISTINCT z.studentno,s.studentname\r\n" + "from ztecheckjob z\r\n"
				+ "INNER JOIN ztestudent s on s.studentid=z.studentno\r\n"
				+ "INNER JOIN zteclassInfo c on c.CLASSID = s.classid\r\n" + "where z.studentno=?\r\n"
				+ "and c.classid=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, studentids);
			pstmt.setInt(2, classid);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				String studentid = rs.getString("studentno");
				String studentname = rs.getString("studentname");
				Excel excel = new Excel(studentid, studentname, studentid);
				excelList.add(excel);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return excelList;
	}

}
