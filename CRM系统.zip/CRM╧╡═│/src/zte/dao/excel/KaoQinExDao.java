package zte.dao.excel;

import java.util.List;

import zte.utils.CheckVoEX;

public interface KaoQinExDao {

	/**
	 * ��ȡ��ѯ������Ϣ����
	 * 
	 * @param majorid
	 * @param classid
	 * @param stuName
	 * @param checkDate
	 * @param checkStatu
	 * @return
	 */
	int getCheckVoCount(String majorid, String classid, String stuName, String checkDate, String checkStatu);

	/**
	 * ��ȡ��������Ϣ�б�
	 * 
	 * @param curpage
	 * @param size
	 * @param majorid
	 * @param classid
	 * @param stuName
	 * @param checkDate
	 * @param checkStatu
	 * @return
	 */
	List<CheckVoEX> getCheckVoList(int curpage, int size, String majorid, String classid, String stuName,
			String checkDate, String checkStatu);

}
