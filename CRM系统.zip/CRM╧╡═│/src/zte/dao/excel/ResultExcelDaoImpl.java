package zte.dao.excel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import zte.dao.BaseDao;
import zte.entity.Excel;
import zte.entity.VO.StudentVOclassInfo;

public class ResultExcelDaoImpl extends BaseDao implements ResultExcelDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	/**
	 * ���ݰ༶ ѧ�������ҵ���ѧ������µ����м�¼ ����ȡ�ð����в���ĳ�������
	 */
	@Override
	public List<Excel> getResult(int studentids, String data, int type, int classid) {
		conn = this.getConnection();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<Excel> excelList = new ArrayList<Excel>();
		conn = this.getConnection();
		String sql = "select DISTINCT z.examdate,r.studentRESULT\r\n" + "from zteresult z\r\n"
				+ "INNER JOIN ztestudent s on s.studentid=z.studentid\r\n"
				+ "INNER JOIN zteclassInfo c on c.CLASSID = s.classid\r\n" + "LEFT JOIN(\r\n"
				+ "select DISTINCT z.examdate,z.studentresult\r\n" + "from zteresult z\r\n"
				+ "INNER JOIN ztestudent s on s.studentid=z.studentid\r\n"
				+ "INNER JOIN zteclassInfo c on c.CLASSID = s.classid\r\n" + "where EXAMTYPE=?\r\n"
				+ "and z.studentid=?\r\n" + "and c.classid=?\r\n"
				+ "and (to_char(z.examdate,'yyyy-MM-dd hh24:mi:ss') LIKE ?)\r\n" + "ORDER BY examdate \r\n"
				+ ") r on z.examdate=r.EXAMDATE\r\n" + "where EXAMTYPE=?\r\n" + "and c.classid=?\r\n"
				+ "and (to_char(z.examdate,'yyyy-MM-dd hh24:mi:ss') LIKE ?)\r\n" + "ORDER BY examdate ";

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, type);
			pstmt.setInt(2, studentids);
			pstmt.setInt(3, classid);
			pstmt.setString(4, data);
			pstmt.setInt(5, type);
			pstmt.setInt(6, classid);
			pstmt.setString(7, data);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String examdate = sdf.format(rs.getTimestamp("examdate"));
				String studentresult = rs.getString("studentresult");
				// �����ݷ�װ����������ȥ
				Excel excel = new Excel(examdate, studentresult);
				excelList.add(excel);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return excelList;
	}

	/**
	 * ͨ������İ༶���ڲ����Ҫ���ѧ������ �Դ˾�������������
	 */
	@Override
	public List<Excel> getcount(String data, int type, int classid) {
		conn = this.getConnection();
		List<Excel> excelList = new ArrayList<Excel>();
		String sql = "select  DISTINCT  z.STUDENTid from zteresult z INNER JOIN ztestudent s on s.studentid=z.studentid INNER JOIN zteclassInfo c on c.CLASSID = s.classid where EXAMTYPE=? and c.classid=? and (to_char(z.examdate,'yyyy-MM-dd hh24:mi:ss') LIKE ?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, type);
			pstmt.setInt(2, classid);
			pstmt.setString(3, data);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String studentid = rs.getString("studentid");
				Excel excel = new Excel(studentid);
				excelList.add(excel);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return excelList;
	}

	// ��ȡѧ�ź�����
	@Override
	public List<Excel> getResults(int studentids, int type, int classid) {
		conn = this.getConnection();
		List<Excel> excelList = new ArrayList<Excel>();
		String sql = "select DISTINCT z.studentid,s.studentname\r\n" + "from zteresult z\r\n"
				+ "INNER JOIN ztestudent s on s.studentid=z.studentid\r\n"
				+ "INNER JOIN zteclassInfo c on c.CLASSID = s.classid\r\n" + "where z.studentid=?\r\n"
				+ "and EXAMTYPE=?\r\n" + "and c.classid=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, studentids);
			pstmt.setInt(2, type);
			pstmt.setInt(3, classid);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				String studentid = rs.getString("studentid");
				String studentname = rs.getString("studentname");
				Excel excel = new Excel(studentid, studentname, studentid);
				excelList.add(excel);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return excelList;
	}

}
