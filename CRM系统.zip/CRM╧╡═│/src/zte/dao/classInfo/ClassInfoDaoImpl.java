package zte.dao.classInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import zte.dao.BaseDao;
import zte.entity.ClassInfo;

public class ClassInfoDaoImpl extends BaseDao implements ClassInfoDao {
	Scanner input = new Scanner(System.in);
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public List<ClassInfo> ShowInfo() {
		conn = this.getConnection();
		List<ClassInfo> ClassInfoList = new ArrayList<ClassInfo>();
		String sql = "select * from zteclassInfo";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int ClassId = rs.getInt(1);
				String ClassName = rs.getString(2);
				int ClassType = rs.getInt(3);
				ClassInfo classInfo = new ClassInfo(ClassId, ClassName, ClassType);
				ClassInfoList.add(classInfo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return ClassInfoList;
	}

	public List<ClassInfo> GetClassByName(String classname) {
		ClassInfo classInfo = null;
		conn = this.getConnection();
		List<ClassInfo> ClassInfoList = new ArrayList<ClassInfo>();
		String sql = "select * from zteclassInfo where studytype=(select id from ztemajor where major=? )";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, classname);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int ClassId = rs.getInt(1);
				String ClassName = rs.getString(2);
				int ClassType = rs.getInt(3);
				classInfo = new ClassInfo(ClassId, ClassName, ClassType);
				ClassInfoList.add(classInfo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return ClassInfoList;
	}

	@Override
	public List<ClassInfo> ShowInfo(String studyType) {
		ClassInfo classInfo = null;
		conn = this.getConnection();
		List<ClassInfo> ClassInfoList = new ArrayList<ClassInfo>();
		String sql = "select * from zteclassInfo where studytype=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, studyType);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int ClassId = rs.getInt(1);
				String ClassName = rs.getString(2);
				int ClassType = rs.getInt(3);
				classInfo = new ClassInfo(ClassId, ClassName, ClassType);
				ClassInfoList.add(classInfo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return ClassInfoList;
	}

	@Override
	public boolean addClass(ClassInfo classInfo) {
		boolean flag = false;
		String sql = "insert into zteclassInfo values(zteclassInfo_seq.nextval,?,?) ";
		Object[] params = { classInfo.getClassName(), classInfo.getClassType(), };
		int count = this.exeUpdate(sql, params);
		if (count > 0) {
			flag = true;
		}
		return flag;
	}

	@Override
	public boolean updateClassInfo(ClassInfo classInfo) {
		String sql = "update zteclassInfo set  className=?,studyType=? where classId=? ";
		Object params[] = { classInfo.getClassName(), classInfo.getClassType(), classInfo.getClassId() };
		if (this.exeUpdate(sql, params) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean pdClass(String stuNo) {
		boolean flse = false;
		conn = this.getConnection();

		String sql = "select classid from ztestudent where classid=(select classid from zteclassInfo where classid=?) ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, stuNo);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				flse = true;

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return flse;

	}

	@Override
	public boolean delete(String classId) {
		conn = this.getConnection();
		boolean flse = false;
		String sql = "delete from zteclassInfo where classid=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, classId);

			int count = pstmt.executeUpdate();
			if (count > 0) {

				flse = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return flse;
	}

}
