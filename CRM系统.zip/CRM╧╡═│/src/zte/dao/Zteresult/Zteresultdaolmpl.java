package zte.dao.Zteresult;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import zte.dao.BaseDao;
import zte.entity.Major;

public class Zteresultdaolmpl extends BaseDao implements Zteresultdao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	// ����ѧ�����ӳ�������
	@Override
	public boolean add(List<String> list, String result) {
		conn = this.getConnection();

		Calendar ca = Calendar.getInstance();
		int year = ca.get(Calendar.YEAR);// ��ȡ���
		int month = ca.get(Calendar.MONTH) + 1;// ��ȡ�·� �·���Ҫ��1
		int day = ca.get(Calendar.DATE);// ��ȡ��
		String sql = null;
		int reult = 0;
		for (String String : list) {
			sql = "insert into zteresult values(zteresult_seq.nextval," + String + ",to_date('" + year + "-" + month
					+ "-" + day + "','yyyy-MM-dd'),1, '" + result + "' )";
			try {
				pstmt = conn.prepareStatement(sql);
				reult = pstmt.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (reult > 0) {
			return true;
		}

		return false;
	}

	// ����ѧ�������ܿ�����
	@Override
	public boolean addweek(List<String> studentnolist, String result) {
		conn = this.getConnection();

		Calendar ca = Calendar.getInstance();
		int year = ca.get(Calendar.YEAR);// ��ȡ���
		int month = ca.get(Calendar.MONTH) + 1;// ��ȡ�·� �·���Ҫ��1
		int day = ca.get(Calendar.DATE);// ��ȡ��
		String sql = null;
		int reult = 0;
		for (String String : studentnolist) {
			sql = "insert into zteresult values(zteresult_seq.nextval," + String + ",to_date('" + year + "-" + month
					+ "-" + day + "','yyyy-MM-dd'),2, '" + result + "' )";
			try {
				pstmt = conn.prepareStatement(sql);
				reult = pstmt.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (reult > 0) {
			return true;
		}

		return false;
	}

	// �����Զ�ˢ��
	@Override
	public boolean shuaxin() {
		// ��ѯ��ǰʱ��������
		conn = this.getConnection();
		Calendar ca = Calendar.getInstance();
		int year = ca.get(Calendar.YEAR);// ��ȡ���
		int month = ca.get(Calendar.MONTH) + 1;// ��ȡ�·� �·���Ҫ��1
		int day = ca.get(Calendar.DATE);// ��ȡ��
		String str = null;
		if (month < 10) {
			str = year + "-0" + month + "-" + day;
			System.out.println(str);
		} else {
			str = year + "-" + month + "-" + day;
			System.out.println(str);

		}

		String sql = "select max(examdate)  from zteresult ";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next())
				if (rs.getDate("max(examdate)") != null) {
					Date date = rs.getDate("max(examdate)");
					System.out.println(date);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String old = sdf.format(date);
					System.out.println(old);
					if (!str.equals(old)) {
						String sql2 = "delete from zteresult where examType=1 ";
						pstmt = conn.prepareStatement(sql2);
						int count = pstmt.executeUpdate();
						if (count > 0) {
							return true;
						}
					}
				}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean shuaxinweek() {
		// ��ѯ��ǰʱ��������
		conn = this.getConnection();
		Calendar ca = Calendar.getInstance();// ����һ������ʵ��

		ca.setTime(new Date());// ʵ����һ������

		int week = ca.get(Calendar.WEEK_OF_YEAR);// ��ȡ�ǵڼ���

		String sql = "select max(examdate)  from zteresult ";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next())
				if (rs.getDate("max(examdate)") != null) {
					Date date = rs.getDate("max(examdate)");
					ca.setTime(date);
					int week2 = ca.get(Calendar.WEEK_OF_YEAR);

					System.out.println(week);
					if (week2 != week) {

						String sql2 = "delete from zteresult where examType=2 ";
						pstmt = conn.prepareStatement(sql2);
						int count = pstmt.executeUpdate();
						if (count > 0) {
							return true;
						}
					}
				}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
