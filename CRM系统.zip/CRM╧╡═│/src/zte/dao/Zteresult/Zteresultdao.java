package zte.dao.Zteresult;

import java.util.List;

public interface Zteresultdao {

	boolean add(List<String> list, String result);

	boolean addweek(List<String> studentnolist, String result);

	boolean shuaxin();

	boolean shuaxinweek();

}
