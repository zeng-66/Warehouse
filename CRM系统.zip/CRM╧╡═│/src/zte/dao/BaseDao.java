package zte.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * 
 * 
 * @author Sunshine
 */
public class BaseDao {

	
	String url = "jdbc:oracle:thin:@localhost:1521:ORCL";
	String user = "zhangsan";
	String password = "sa123";

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	/**
	 * 连接数据库的通用方法
	 * @return
	 */
	public Connection getConnection() {
		// 1.加载驱动 将OracleDriver对象加载到内存里面
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			// 建立和数据库的连接
			conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 * 关闭资源的通用方法
	 * @param conn
	 * @param pstmt
	 * @param rs
	 */
	public void closeAll(Connection conn,PreparedStatement pstmt,ResultSet rs) {
		try {
			if (rs!=null) {
				rs.close();
			}
			if (pstmt!=null) {
				pstmt.close();
			}
			if (conn!=null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 遍历参数的通用方法
	 * @param sql
	 * @param params
	 * @return
	 */
	public int exeUpdate(String sql,Object[] params){
		int count=0;
		conn=this.getConnection();
		try {
			pstmt=conn.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				pstmt.setObject((i+1),params[i]);
			}
			count= pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			this.closeAll(conn, pstmt, rs);
		}
		return count;
	}
	
}
