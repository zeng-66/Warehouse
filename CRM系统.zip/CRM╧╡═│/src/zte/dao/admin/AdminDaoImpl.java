package zte.dao.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import zte.dao.BaseDao;
import zte.entity.Admin;

public class AdminDaoImpl extends BaseDao implements AdminDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public Admin login(String loginCode, String passWord) {
		conn = this.getConnection();
		Admin admin = null;
		String sql = "select id,logincode,roleid,password,createtime from zteAdmin where logincode=? and password=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, loginCode);
			pstmt.setString(2, passWord);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String logincode = rs.getString("logincode");
				int roleid = rs.getInt("roleid");
				String password = rs.getString("password");
				String createtime = rs.getString("createtime");
				// ��������
				admin = new Admin(id, logincode, roleid, password, createtime);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return admin;
	}

}
