package zte.dao.admin;

import zte.entity.Admin;

public interface AdminDao {

	/**
	 * ��¼
	 * 
	 * @param loginCode
	 * @param password
	 * @return
	 */
	Admin login(String loginCode, String password);

}
