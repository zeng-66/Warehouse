package zte.dao.MarketClass;

import java.util.List;

import zte.entity.MarketClass;

public interface MarketclassDao {

	/**
	 * ��ҳ��ѯ
	 * @param studyType
	 * @param currentPageNo
	 * @param pageSize
	 * @return
	 */
	List<MarketClass> ShowmarterList(String studyType, int currentPageNo, int pageSize);

    /**
     * �жϰ����Ƿ�����
     * @param classId
     * @return
     */
	boolean pdClass(String classId);

	/**
	 * ɾ��
	 * @param classId
	 * @return
	 */
	boolean delete(String classId);

	/**
	 * ���ݰ༶�Ų�ѯ���а༶��Ϣ
	 * @param marketId
	 * @return
	 */
	List<MarketClass> getMarketclassbyId(String marketId);

	/**
	 * �޲β�ѯ
	 * @return
	 */
	public List<MarketClass> ShowInfo();

}
