package zte.dao.MarketClass;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import zte.dao.BaseDao;
import zte.entity.MarketClass;
import zte.entity.VO.ClassInfoVOmajorInfo;

public class MarketclassDaolmpl extends BaseDao implements MarketclassDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	/**
	 * ��ѯ��ҳ��
	 * 
	 * @param studyType
	 * @return
	 */
	public int getmarketclassCount(String studyType) {

		int totalCount = 0;// ��ҳ��ѯ��������
		conn = this.getConnection();
		StringBuffer sql = new StringBuffer("select count(*) from marketClass where 1=1 ");
		List<Object> params = new ArrayList<Object>();
		if (studyType != null && !"".equals(studyType)) {
			sql.append(" and classType =? ");
			// �������������ӵ�����������
			params.add(studyType);
		}

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				totalCount = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return totalCount;

	}

	@Override
	public List<MarketClass> ShowmarterList(String studyType1, int currentPageNo, int pageSize) {
		List<MarketClass> marketClasses = new ArrayList<MarketClass>();
		conn = this.getConnection();
		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer("select * from (select rownum rn ,m.* from marketClass m where 1=1 ");
		if (studyType1 != null && !"".equals(studyType1)) {
			sql.append(" and classType=? ");
			// �������������ӵ�����������
			params.add(studyType1);
		}

		// ƴ��SQL���
		sql.append(" and  rownum<=? ) where rn>? ");
		// rownum���� ����ǰҳ��*ҳ��ߴ�
		params.add(currentPageNo * pageSize);
		// rn������(��ǰҳ��-1)*ҳ��ߴ�
		params.add((currentPageNo - 1) * pageSize);

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String mkClassId = rs.getString("mkClassId");
				String className = rs.getString("className");
				String classType = rs.getString("classType");

				MarketClass marketClass = new MarketClass(mkClassId, className, classType);
				marketClasses.add(marketClass);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return marketClasses;
	}

	public List<MarketClass> addclass() {
		List<MarketClass> marketClasses = new ArrayList<MarketClass>();
		conn = this.getConnection();
		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer("select distinct classtype from  marketClass  where 1=1 ");

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String classType = rs.getString("classType");

				MarketClass marketClass = new MarketClass(classType);
				marketClasses.add(marketClass);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return marketClasses;
	}

	/**
	 * ���Ӱ༶����
	 * 
	 * @param className
	 * @param studytype
	 * @return
	 */
	public boolean addClass(String className, String studytype) {
		conn = this.getConnection();

		StringBuffer sql = new StringBuffer(
				"insert into marketclass values(mkclass_seq.nextval,'" + className + "'," + studytype + ")");
		try {
			pstmt = conn.prepareStatement(sql.toString());
			int sou = pstmt.executeUpdate();
			if (sou > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	public List<MarketClass> ShowInfo() {

		List<MarketClass> marketClasses = new ArrayList<MarketClass>();
		conn = this.getConnection();
		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer("select * from  marketClass  where 1=1 ");

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String mkClassId = rs.getString("mkClassId");
				String className = rs.getString("className");
				String classType = rs.getString("classType");

				MarketClass marketClass = new MarketClass(mkClassId, className, classType);
				marketClasses.add(marketClass);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return marketClasses;
	}

	public List<MarketClass> getMarketclassbyId(String marketId) {

		List<MarketClass> marketClasses = new ArrayList<MarketClass>();
		conn = this.getConnection();
		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer("select * from  marketClass  where 1=1 ");
		if (null != marketId && !"".equals(marketId)) {
			sql.append(" and classType=? ");
			// �������������ӵ�����������
			params.add(marketId);
		}

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String mkClassId = rs.getString("mkClassId");
				String className = rs.getString("className");
				String classType = rs.getString("classType");

				MarketClass marketClass = new MarketClass(mkClassId, className, classType);
				marketClasses.add(marketClass);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return marketClasses;
	}

	
	/**
	 * �޸�
	 * @param classId
	 * @param className
	 * @param studyType
	 * @return
	 */
	public boolean updateClassInfo(String classId, String className, String studyType) {
		String sql = "update marketclass set  className='" + className + "',classType=" + studyType
				+ " where mkclassId=" + classId + " \r\n";
		conn = this.getConnection();

		try {
			pstmt = conn.prepareStatement(sql.toString());
			int sou1 = pstmt.executeUpdate();
			if (sou1 > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean pdClass(String classId) {

		boolean flse = false;
		conn = this.getConnection();

		String sql = "select mkClassId from marketStudent where mkClassId=(select mkClassId from marketClass where mkClassId=?) ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, classId);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				flse = true;

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return flse;

	}

	@Override
	public boolean delete(String classId) {

		conn = this.getConnection();
		boolean flse = false;
		String sql = "delete from marketClass where mkClassId=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, classId);

			int count = pstmt.executeUpdate();
			if (count > 0) {

				flse = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return flse;

	}

}
