package zte.dao.ztecheckjob;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import zte.dao.BaseDao;

public class ZtecheckjobDaoImpl extends BaseDao implements ZtecheckjobDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public boolean add(List<String> list, String result) {
		// ��ѯ��ǰʱ��������
		conn = this.getConnection();

		Calendar ca = Calendar.getInstance();
		int year = ca.get(Calendar.YEAR);// ��ȡ���
		int month = ca.get(Calendar.MONTH) + 1;// ��ȡ�·� �·���Ҫ��1
		int day = ca.get(Calendar.DATE);// ��ȡ��
		String sql = null;
		int reult = 0;
		for (String String : list) {
			sql = "insert into ztecheckjob values(ztecheckjob_seq.nextval," + String + ",to_date('" + year + "-" + month
					+ "-" + day + "','yyyy-MM-dd'), '" + result + "' )";
			try {
				pstmt = conn.prepareStatement(sql);
				reult = pstmt.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (reult > 0) {
			return true;
		}
		return false;
	}
}
