package zte.dao.major;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import zte.dao.BaseDao;
import zte.entity.Major;

public class MajorDaoImpl extends BaseDao implements MajorDao {

	Scanner input = new Scanner(System.in);
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public List<Major> ShowInfo() {
		conn = this.getConnection();
		List<Major> MajorList = new ArrayList<Major>();
		String sql = "select * from ztemajor";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int MajorId = rs.getInt(1);
				String Major = rs.getString(2);
				Major classInfo = new Major(MajorId, Major);
				MajorList.add(classInfo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return MajorList;
	}

}
