package zte.dao.major;

import java.util.List;

import zte.entity.Major;

public interface MajorDao {

	/**
	 * ��ѯ����רҵ��Ϣ
	 * 
	 * @return
	 */
	List<Major> ShowInfo();
}
