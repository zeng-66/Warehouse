package zte.dao.student;

import zte.entity.Student;

public interface StudentDao {

	/**
	 * ע��ѧ����Ϣ
	 * 
	 * @param student
	 * @return
	 */
	boolean AddStudent(Student student);

	/**
	 * ɾ��ѧ����Ϣ
	 * 
	 * @param stuNo
	 * @return
	 */
	boolean delete(String stuNo);

	/**
	 * �޸�ѧ����Ϣ
	 * 
	 * @param student
	 * @return
	 */
	boolean updateStudentInfo(Student student);
}
