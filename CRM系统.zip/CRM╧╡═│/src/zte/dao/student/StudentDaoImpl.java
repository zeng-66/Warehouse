package zte.dao.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import zte.dao.BaseDao;
import zte.entity.Student;

public class StudentDaoImpl extends BaseDao implements StudentDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public boolean AddStudent(Student student) {
		boolean flag = false;
		String sql = "insert into ztestudent values(ztestudent_seq.nextval,?,?,?,?,?,?) ";
		Object[] params = { student.getStudentName(), student.getClassId(), student.getFromSchool(),
				student.getEducation(), student.getLoginCode(), student.getPassword() };
		int count = this.exeUpdate(sql, params);
		if (count > 0) {
			flag = true;
		}
		return flag;
	}

	@Override
	public boolean delete(String stuNo) {
		String sql = "delete from ztestudent where studentId=?";
		Object[] params = { stuNo };
		if (this.exeUpdate(sql, params) > 0) {
			return true;
		}
		return false;

	}

	@Override
	public boolean updateStudentInfo(Student student) {
		String sql = "update ztestudent set studentName=?,classid=?,fromschool=?,education=?,logincode=?,password=? where studentid=? ";
		Object params[] = { student.getStudentName(), student.getClassId(), student.getFromSchool(),
				student.getEducation(), student.getLoginCode(), student.getPassword(), student.getStudentid() };
		if (this.exeUpdate(sql, params) > 0) {
			return true;
		}
		return false;
	}

}
