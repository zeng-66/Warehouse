package zte.dao.marketstudent;

import zte.entity.MarketStudent;

public interface MarketStudentDao {

	/**
	 * ע���г�ѧ����Ϣ
	 * 
	 * @param marketstudent
	 * @return
	 */
	boolean addMarketStudent(MarketStudent marketstudent);

	/**
	 * ɾ��
	 * 
	 * @param studentId
	 * @return
	 */
	boolean delete(String studentId);

	/**
	 * �޸�
	 * 
	 * @param marketStudent
	 * @return
	 */
	boolean updateStudentInfo(MarketStudent marketstudent);

}
