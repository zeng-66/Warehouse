package zte.dao.marketstudent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import zte.dao.BaseDao;
import zte.dao.admin.AdminDao;
import zte.dao.admin.AdminDaoImpl;
import zte.entity.Admin;
import zte.entity.MarketStudent;

public class MarketStudentDaoImpl extends BaseDao implements MarketStudentDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	// ע��
	@Override
	public boolean addMarketStudent(MarketStudent marketstudent) {

		Calendar ca = Calendar.getInstance();
		int year = ca.get(Calendar.YEAR);// ��ȡ���
		int month = ca.get(Calendar.MONTH) + 1;// ��ȡ�·� �·���Ҫ��1
		int day = ca.get(Calendar.DATE);// ��ȡ��
		String str = null;
		if (month < 10) {
			str = year + "-0" + month + "-" + day;
			System.out.println(str);
		} else {
			str = year + "-" + month + "-" + day;
			System.out.println(str);

		}

		conn = this.getConnection();
		int roleid = 0;
		String sql = "insert into marketStudent values(marketstudent_seq.nextval,?,?,?,?,?,?,?,?,?,to_date(?,'yyyy-MM-dd'),(select id from zteadmin where logincode = ?),?,?)";
		Object[] params = { marketstudent.getStudentName(), Integer.parseInt(marketstudent.getMkClassId()),
				marketstudent.getFromschool(), marketstudent.getEducation(), marketstudent.getPhone(),
				marketstudent.getQq(), Integer.parseInt(marketstudent.getXinge()), marketstudent.getBeizhu(),
				Integer.parseInt(marketstudent.getWilltrain()), str, marketstudent.getCreateauthorID(),
				marketstudent.getModifyauthor(), marketstudent.getModifyauthorTime() };
		if (this.exeUpdate(sql, params) > 0) {
			return true;
		}
		return false;
	}

	// ɾ��
	@Override
	public boolean delete(String studentId) {
		conn = this.getConnection();
		String sql = "delete from marketStudent where id=? ";
		Object[] params = { studentId };
		if (this.exeUpdate(sql, params) > 0) {
			return true;
		}
		return false;
	}

	// �޸�
	@Override
	public boolean updateStudentInfo(MarketStudent marketstudent) {

		Calendar ca = Calendar.getInstance();
		int year = ca.get(Calendar.YEAR);// ��ȡ���
		int month = ca.get(Calendar.MONTH) + 1;// ��ȡ�·� �·���Ҫ��1
		int day = ca.get(Calendar.DATE);// ��ȡ��
		String str = null;
		if (month < 10) {
			str = year + "-0" + month + "-" + day;
			System.out.println(str);
		} else {
			str = year + "-" + month + "-" + day;
			System.out.println(str);

		}

		List<Admin> admins = new ArrayList<Admin>();
		String sql = "update marketstudent set studentname=?, mkclassId=?, fromSchool=?,"
				+ " education=?, phone=?, qq=?, xinge=?, beizhu=?, willTrain=?,"
				+ " modifyauthor=(select id from zteadmin where logincode = ?),modifyauthorTime=to_date(?,'yyyy-MM-dd') where id=?\r\n";
		Object[] params = {

				marketstudent.getStudentName(), Integer.parseInt(marketstudent.getMkClassId()),
				marketstudent.getFromschool(), marketstudent.getEducation(), marketstudent.getPhone(),
				marketstudent.getQq(), Integer.parseInt(marketstudent.getXinge()), marketstudent.getBeizhu(),
				Integer.parseInt(marketstudent.getWilltrain()), marketstudent.getModifyauthor(), str,
				Integer.parseInt(marketstudent.getStudentId())

		};
		if (this.exeUpdate(sql, params) > 0) {
			return true;
		}
		return false;
	}
}
