package zte.dao.VO.classinfoVOmajoorinfoVOstudentinfoDao;

import java.util.List;

import zte.entity.VO.ClassinfoVOmajoorinfoVOstudentinfo;

public interface ClassinfoVOmajoorinfoVOstudentinfoDao {

	List<ClassinfoVOmajoorinfoVOstudentinfo> ShowclassinfoVOmajoorinfoVOstudentinfos(String id1, String studyType1,
			int currentPageNo, int pageSize);

	List<ClassinfoVOmajoorinfoVOstudentinfo> ShowclassinfoVOmajoorinfoVOstudentinfosweek(String id1, String studyType1,
			int currentPageNo, int pageSize);

}
