package zte.dao.VO.classInfoVOmajorInfo;

import java.util.List;

import zte.entity.VO.ClassInfoVOmajorInfo;

public interface ClassInfoVOmajorInfoDao {

	/**
	 * ��ȡclassInfo��majorInfo���ܼ�¼��
	 * 
	 * @param studyType
	 * @return
	 */
	int getclassInfoVOmajorInfoCount(String studyType);

	/**
	 * ��ȡ�༶��רҵ��Ϣ
	 * 
	 * @param studyType
	 * @param currentPageNo
	 * @param pageSize
	 * @return
	 */
	List<ClassInfoVOmajorInfo> ShowclassInfoVOmajorInfoList(String studyType, int currentPageNo, int pageSize);
}
