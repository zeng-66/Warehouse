package zte.dao.VO.classInfoVOmajorInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import zte.dao.BaseDao;
import zte.entity.VO.ClassInfoVOmajorInfo;

public class ClassInfoVOmajorInfoDaoImpl extends BaseDao implements ClassInfoVOmajorInfoDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public List<ClassInfoVOmajorInfo> ShowclassInfoVOmajorInfoList(String StudyType, int currentPage, int pageSize) {

		List<ClassInfoVOmajorInfo> classVOmajorList = new ArrayList<ClassInfoVOmajorInfo>();
		conn = this.getConnection();
		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer("select * \r\n" + "from( \r\n" + "select rownum rn,c.*,m.*\r\n"
				+ "from ztemajor m inner join zteclassInfo c on m.id=c.studytype \r\n" + "where 1=1 ");
		if (StudyType != null && !"".equals(StudyType)) {
			sql.append(" and c.studytype=? ");
			// �������������ӵ�����������
			params.add(StudyType);
		}

		// ƴ��SQL���
		sql.append(" and  rownum<=? ) where rn>? ");
		// rownum���� ����ǰҳ��*ҳ��ߴ�
		params.add(currentPage * pageSize);
		// rn������(��ǰҳ��-1)*ҳ��ߴ�
		params.add((currentPage - 1) * pageSize);

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String classId = rs.getString("classId");
				String className = rs.getString("className");
				String studytype = rs.getString("studytype");
				String major = rs.getString("major");
				String id = rs.getString("id");

				ClassInfoVOmajorInfo student = new ClassInfoVOmajorInfo(classId, className, id, studytype, major);
				classVOmajorList.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return classVOmajorList;

	}

	@Override
	public int getclassInfoVOmajorInfoCount(String studyType) {
		int totalCount = 0;// ��ҳ��ѯ��������
		conn = this.getConnection();
		StringBuffer sql = new StringBuffer(
				"select count(*) from ztemajor m\r\n" + "inner join zteclassInfo c on m.id=c.studytype where 1=1  ");
		List<Object> params = new ArrayList<Object>();
		if (studyType != null && !"".equals(studyType)) {
			sql.append(" and c.studytype=? ");
			// �������������ӵ�����������
			params.add(studyType);
		}

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				totalCount = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return totalCount;
	}

}
