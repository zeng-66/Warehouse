package zte.dao.VO.marketStudentVOmarketClass;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import zte.dao.BaseDao;
import zte.entity.VO.MarketStudentVOmarketClass;

public class MarketStudentVOmarketClassDaoImpl extends BaseDao implements MarketStudentVOmarketClassDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public List<MarketStudentVOmarketClass> showmarketStudentVOmarketClassList(String willtrain, String classId,
			String classType, String studentName, int currentPage, int pageSize) {

		List<MarketStudentVOmarketClass> list = new ArrayList<MarketStudentVOmarketClass>();
		conn = this.getConnection();
		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer("select * from (\r\n"
				+ "select rownum rn,s.id,studentname,className,fromschool,education,phone,qq,xinge,beizhu,willtrain,s.createtime,\r\n"
				+ "s.createauthorid,modifyauthor,modifyauthorTime,c.mkclassid,classtype,roleid,logincode\r\n"
				+ "from marketStudent s \r\n" + "inner join zteadmin a on a.roleid=s.createauthorid\r\n"
				+ "inner join marketclass c on s.mkclassid=c.mkclassid where 1=1 ");
		if (willtrain != null && !"".equals(willtrain)) {
			sql.append(" and willtrain=? ");
			// �������������ӵ�����������
			params.add(willtrain);
		}
		if (classId != null && !"".equals(classId)) {
			sql.append(" and c.mkclassId=? ");
			// �������������ӵ�����������
			params.add(classId);
		}
		if (classType != null && !"".equals(classType)) {
			sql.append(" and classType=? ");
			// �������������ӵ�����������
			params.add(classType);
		}
		if (studentName != null && !"".equals(studentName)) {
			sql.append(" and studentName like ? ");
			// �������������ӵ�����������
			params.add("%" + studentName + "%");
		}

		// ƴ��SQL���
		if (currentPage != 0) {
			sql.append(" and  rownum<=? ");
		} else {
			sql.append(" and  0=? ");
		}
		sql.append(" ) where rn>? ");

		// rownum���� ����ǰҳ��*ҳ��ߴ�
		params.add(currentPage * pageSize);
		// rn������(��ǰҳ��-1)*ҳ��ߴ�
		params.add((currentPage - 1) * pageSize);

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String Id = rs.getString("id");
				String studentname = rs.getString("studentname");
				String classname = rs.getString("className");
				String fromschool = rs.getString("fromschool");
				String education = rs.getString("education");
				String phone = rs.getString("phone");
				String qq = rs.getString("qq");
				String xinge = rs.getString("xinge");
				String beizhu = rs.getString("beizhu");
				String willTrain = rs.getString("willtrain");
				String createtime = rs.getString("createtime");
				String createauthorid = rs.getString("createauthorid");
				String modifyauthor = rs.getString("modifyauthor");
				String modifyauthorTime = rs.getString("modifyauthorTime");
				String mkclassid = rs.getString("mkclassid");
				String classtype = rs.getString("classtype");
				String roleId = rs.getString("roleid");
				String loginCode = rs.getString("logincode");
				MarketStudentVOmarketClass marketstudentVOmarketclass = new MarketStudentVOmarketClass(Id, studentname,
						mkclassid, fromschool, education, phone, qq, xinge, beizhu, willTrain, createtime,
						createauthorid, modifyauthor, modifyauthorTime, classname, classtype, roleId, loginCode);
				list.add(marketstudentVOmarketclass);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return list;
	}

	// �ܼ�¼��
	@Override
	public int getmarketStudentVOmarketClassCount(String willtrain, String classId, String classType,
			String studentName) {
		int totalCount = 0;// ��ҳ��ѯ��������
		conn = this.getConnection();
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer(
				"select count(*) from marketStudent s \r\n" + "inner join zteadmin a on a.roleid=s.createauthorid\r\n"
						+ "inner join marketclass c on s.mkclassid=c.mkclassid where 1=1 ");
		if (willtrain != null && !"".equals(willtrain)) {
			sql.append(" and willtrain=? ");
			// �������������ӵ�����������
			params.add(willtrain);
		}
		if (classId != null && !"".equals(classId)) {
			sql.append(" and c.mkclassId=? ");
			// �������������ӵ�����������
			params.add(classId);
		}
		if (classType != null && !"".equals(classType)) {
			sql.append(" and classType=? ");
			// �������������ӵ�����������
			params.add(classType);
		}
		if (studentName != null && !"".equals(studentName)) {
			sql.append(" and studentName like ? ");
			// �������������ӵ�����������
			params.add("%" + studentName + "%");
		}

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				totalCount = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return totalCount;
	}

	// ����ѧ�Ų�ѯѧ����Ϣ
	@Override
	public MarketStudentVOmarketClass getstudentInfo(String studenteId) {
		MarketStudentVOmarketClass studentInfo = null;
		conn = this.getConnection();
		String sql = "select s.id,studentname,className,fromschool,education,phone,qq,xinge,beizhu,willtrain,s.createtime,\r\n"
				+ "s.createauthorid,modifyauthor,modifyauthorTime,c.mkclassid,classtype,roleid,logincode\r\n"
				+ "from marketStudent s \r\n" + "inner join zteadmin a on a.roleid=s.createauthorid\r\n"
				+ "inner join marketclass c on s.mkclassid=c.mkclassid where s.id=? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, studenteId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String Id = rs.getString("id");
				String studentname = rs.getString("studentname");
				String classname = rs.getString("className");
				String fromschool = rs.getString("fromschool");
				String education = rs.getString("education");
				String phone = rs.getString("phone");
				String qq = rs.getString("qq");
				String xinge = rs.getString("xinge");
				String beizhu = rs.getString("beizhu");
				String willTrain = rs.getString("willtrain");
				String createtime = rs.getString("createtime").substring(0, 10);
				String createauthorid = rs.getString("createauthorid");
				String modifyauthor = rs.getString("modifyauthor");
				String modifyauthorTime = rs.getString("modifyauthorTime");
				if (modifyauthorTime != null) {
					modifyauthorTime = rs.getString("modifyauthorTime").substring(0, 10);
				}
				String mkclassid = rs.getString("mkclassid");
				String classtype = rs.getString("classtype");
				String roleId = rs.getString("roleid");
				String loginCode = rs.getString("logincode");
				studentInfo = new MarketStudentVOmarketClass(Id, studentname, mkclassid, fromschool, education, phone,
						qq, xinge, beizhu, willTrain, createtime, createauthorid, modifyauthor, modifyauthorTime,
						classname, classtype, roleId, loginCode);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}

		return studentInfo;
	}

	// ����ѧ�Ų�ѯѧ����Ϣ
	@Override
	public List<MarketStudentVOmarketClass> getstudentInfoList() {
		List<MarketStudentVOmarketClass> studentinfos = new ArrayList<MarketStudentVOmarketClass>();
		;
		conn = this.getConnection();
		String sql = "select s.id,studentname,className,fromschool,education,phone,qq,xinge,beizhu,willtrain,s.createtime,s.createauthorid,modifyauthor,modifyauthorTime,c.mkclassid,classtype,roleid,logincode from marketStudent s inner join zteadmin a on a.roleid=s.createauthorid inner join marketclass c on s.mkclassid=c.mkclassid";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String Id = rs.getString("id");
				String studentname = rs.getString("studentname");
				String classname = rs.getString("className");
				String fromschool = rs.getString("fromschool");
				String education = rs.getString("education");
				String phone = rs.getString("phone");
				String qq = rs.getString("qq");
				String xinge = rs.getString("xinge");
				String beizhu = rs.getString("beizhu");
				String willTrain = rs.getString("willtrain");
				String createtime = rs.getString("createtime");
				String createauthorid = rs.getString("createauthorid");
				String modifyauthor = rs.getString("modifyauthor");
				String modifyauthorTime = rs.getString("modifyauthorTime");
				String mkclassid = rs.getString("mkclassid");
				String classtype = rs.getString("classtype");
				String roleId = rs.getString("roleid");
				String loginCode = rs.getString("logincode");
				MarketStudentVOmarketClass studentInfo = new MarketStudentVOmarketClass(Id, studentname, mkclassid,
						fromschool, education, phone, qq, xinge, beizhu, willTrain, createtime, createauthorid,
						modifyauthor, modifyauthorTime, classname, classtype, roleId, loginCode);
				studentinfos.add(studentInfo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}

		return studentinfos;
	}
}
