package zte.dao.VO.studentVOcheckjobInfo;

import java.util.List;

import zte.entity.VO.StudentVOcheckjobInfo;

public interface StudentVOcheckjobInfoDao {

	/**
	 * ��ѯ��ҵ�����Ϣ
	 * 
	 * @return
	 */
	List<StudentVOcheckjobInfo> ShowCheckjobInfoList(String classId, String studentName, String examdate,
			String studentresult, String resultId, int currentPageNo, int pageSize);

	/**
	 * ��ȡ��ҵ��Ϣ���ܼ�¼��
	 * 
	 * @param classId
	 * @param studentName
	 * @param examdate
	 * @param studentresult
	 * @return
	 */
	int getCheckjobInfoCount(String classId, String studentName, String examdate, String studentresult);

	/**
	 * �޸���ҵ��Ϣ
	 * 
	 * @param stuRes
	 * @return
	 */
	boolean UpdateCheckjobInfo(StudentVOcheckjobInfo stuRes);

	/**
	 * ɾ����ҵ��Ϣ
	 * 
	 * @param id
	 * @return
	 */
	boolean deleteCheckjobInfo(String id);
}
