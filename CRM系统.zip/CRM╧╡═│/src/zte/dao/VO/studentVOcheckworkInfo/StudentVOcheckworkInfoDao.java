package zte.dao.VO.studentVOcheckworkInfo;

import java.util.List;

import zte.entity.VO.StudentVOcheckworkInfo;
import zte.entity.VO.StudnetVOresultInfo;

public interface StudentVOcheckworkInfoDao {

	/**
	 * ��ѯ������Ϣ
	 * 
	 * @return
	 */
	List<StudentVOcheckworkInfo> ShowCheckWorkInfoList(String classId, String studentName, String examdate,
			String studentresult, String resultId, int currentPageNo, int pageSize);

	/**
	 * ��ȡ������Ϣ���ܼ�¼��
	 * 
	 * @param classId
	 * @param studentName
	 * @param examdate
	 * @param studentresult
	 * @return
	 */
	int getCheckWorkInfoCount(String classId, String studentName, String examdate, String studentresult);

	/**
	 * �޸Ŀ�����Ϣ
	 * 
	 * @param stuRes
	 * @return
	 */
	boolean UpdateCheckWorkInfo(StudnetVOresultInfo stuRes);

	/**
	 * ɾ��������Ϣ
	 * 
	 * @param id
	 * @return
	 */
	boolean deleteCheckWorkInfo(String id);
}
