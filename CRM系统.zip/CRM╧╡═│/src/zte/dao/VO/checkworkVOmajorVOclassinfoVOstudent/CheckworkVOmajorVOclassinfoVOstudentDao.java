package zte.dao.VO.checkworkVOmajorVOclassinfoVOstudent;

import java.util.List;

import zte.entity.VO.CheckworkVOmajorVOclassinfoVOstudent;

public interface CheckworkVOmajorVOclassinfoVOstudentDao {

	/**
	 * ���� ��ҳ��ѯ
	 * 
	 * @param studentId
	 * @param id
	 * @param classId
	 * @param currentPageNo
	 * @param pageSize
	 * @return
	 */
	List<CheckworkVOmajorVOclassinfoVOstudent> ShowcheckworkVOmajorVOclassinfoVOstudent(String ckStatu, String id,
			String studyType, int currentPageNo, int pageSize);

	/**
	 * �ܼ�¼��
	 * 
	 * @param id1
	 * @param studyType1
	 * @return
	 */
	int getcheckworkVOmajorVOclassinfoVOstudent(String id1, String studyType1);
}
