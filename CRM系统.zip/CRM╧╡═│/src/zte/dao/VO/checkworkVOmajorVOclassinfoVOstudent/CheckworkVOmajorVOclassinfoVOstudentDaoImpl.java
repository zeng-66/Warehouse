package zte.dao.VO.checkworkVOmajorVOclassinfoVOstudent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import zte.dao.BaseDao;
import zte.entity.VO.CheckworkVOmajorVOclassinfoVOstudent;
import zte.entity.VO.ClassinfoVOmajoorinfoVOstudentinfo;

public class CheckworkVOmajorVOclassinfoVOstudentDaoImpl extends BaseDao
		implements CheckworkVOmajorVOclassinfoVOstudentDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	// ��ҳ��ѯ
	@Override
	public List<CheckworkVOmajorVOclassinfoVOstudent> ShowcheckworkVOmajorVOclassinfoVOstudent(String ckStatu,
			String id, String studyType, int currentPageNo, int pageSize) {
		List<CheckworkVOmajorVOclassinfoVOstudent> cmcsList = new ArrayList<CheckworkVOmajorVOclassinfoVOstudent>();
		conn = this.getConnection();

		Calendar ca = Calendar.getInstance();
		int year = ca.get(Calendar.YEAR);// ��ȡ���
		int month = ca.get(Calendar.MONTH) + 1;// ��ȡ�·� �·���Ҫ��1
		int day = ca.get(Calendar.DATE);// ��ȡ��
		String str = null;
		if (month < 10) {
			str = year + "-0" + month + "-" + day;
			System.out.println(str);
		} else {
			str = year + "-" + month + "-" + day;
			System.out.println(str);

		}

		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		// ��ѯ�����������п��ڵ�ѧ�ŵ�������
		StringBuffer sql = new StringBuffer("select * from (select rownum rn,E1.* from(\r\n"
				+ "select m.id,c.classId,major,className,studytype,studentid,studentName,fromSchool,education,cktime,ckstatu\r\n"
				+ "from ztemajor m\r\n" + "inner join zteclassInfo c on  m.id=c.studytype\r\n"
				+ "inner join ztestudent s on s.classid=c.classid  \r\n"
				+ "left join ztecheckwork k on k.studentNo=s.studentid  where 1=1 ");
		if (id != null && !"".equals(id)) {
			sql.append(" and c.classid = ? ");
			// �������������ӵ�����������
			params.add(id);
		}

		if (studyType != null && !"".equals(studyType)) {
			// �������������ӵ�����������
			sql.append(" and c.studyType = ? ");
			params.add(studyType);
		}
		// ƴ��SQL���
		// ��ѯ�Ѳμӳ�����ѧ����ѧ�Ų��ų�
		sql.append(" order by s.studentid asc ) E1 where E1.studentid not in (select studentno from ztecheckwork ");
		if (str != null && !"".equals(str)) {
			sql.append("where cktime = to_date('" + str + "','yyyy-MM-dd') )");
		} else {
			sql.append(" ) ");

		}
		if (currentPageNo != 0) {
			sql.append(" and rownum<=? ");
		} else {
			sql.append(" and rownum<=0  ");
		}
		sql.append(" ) where rn> ? ");
		// rownum���� ����ǰҳ��*ҳ��ߴ�
		params.add(currentPageNo * pageSize);
		// rn������(��ǰҳ��-1)*ҳ��ߴ�
		params.add((currentPageNo - 1) * pageSize);

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String Id = rs.getString("id");
				String classId = rs.getString("classId");
				String major = rs.getString("major");
				String className = rs.getString("className");
				String studytype = rs.getString("studytype");
				String studentId = rs.getString("studentId");
				String studentName = rs.getString("studentName");
				String fromSchool = rs.getString("fromSchool");
				String education = rs.getString("education");
				String cktime = rs.getString("cktime");
				String ckstatu = rs.getString("ckstatu");
				CheckworkVOmajorVOclassinfoVOstudent cmcs = new CheckworkVOmajorVOclassinfoVOstudent(Id, major, classId,
						className, studytype, studentId, studentName, fromSchool, education, fromSchool, education,
						cktime, ckstatu);
				cmcsList.add(cmcs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cmcsList;
	}

	// �ܼ�¼��
	@Override
	public int getcheckworkVOmajorVOclassinfoVOstudent(String id1, String studyType1) {
		int totalCount = 0;// ��ҳ��ѯ��������
		conn = this.getConnection();

		Calendar ca = Calendar.getInstance();
		int year = ca.get(Calendar.YEAR);// ��ȡ���
		int month = ca.get(Calendar.MONTH) + 1;// ��ȡ�·� �·���Ҫ��1
		int day = ca.get(Calendar.DATE);// ��ȡ��
		String str = null;
		if (month < 10) {
			str = year + "-0" + month + "-" + day;
			System.out.println(str);
		} else {
			str = year + "-" + month + "-" + day;
			System.out.println(str);

		}

		// ��ѯ�����������п��ڵ�ѧ�ŵ�������

		StringBuffer sql = new StringBuffer("select count(*) from (select studentid from ztemajor m\r\n"
				+ "inner join zteclassInfo c on  m.id=c.studytype\r\n"
				+ "inner join ztestudent s on s.classid=c.classid  \r\n"
				+ "left join ztecheckwork k on k.studentNo=s.studentid where 1=1  ");
		List<Object> params = new ArrayList<Object>();
		if (studyType1 != null && !"".equals(studyType1)) {
			sql.append(" and c.studytype=? ");
			// �������������ӵ�����������
			params.add(studyType1);
		}
		if (id1 != null && !"".equals(id1)) {
			sql.append(" and c.classid = ?");
			// �������������ӵ�����������
			params.add(id1);
		}
		sql.append(" order by s.studentid asc ) E1 where E1.studentid not in (select studentno from ztecheckwork ");
		if (str != null && !"".equals(str)) {
			sql.append("where cktime = to_date('" + str + "','yyyy-MM-dd') )");
		} else {
			sql.append(" ) ");

		}
		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				totalCount = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return totalCount;
	}
}
