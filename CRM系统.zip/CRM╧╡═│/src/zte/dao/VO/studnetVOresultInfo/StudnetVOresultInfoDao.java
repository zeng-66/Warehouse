package zte.dao.VO.studnetVOresultInfo;

import java.util.List;

import zte.entity.VO.StudnetVOresultInfo;

public interface StudnetVOresultInfoDao {

	/**
	 * ��ѯ�����ɼ�
	 * 
	 * @return
	 */
	List<StudnetVOresultInfo> ShowMorningResultInfoList(String classId, String studentName, String examdate,
			String studentresult, String resultId, int currentPageNo, int pageSize);

	/**
	 * ��ȡ�����ɼ����ܼ�¼��
	 * 
	 * @param classId
	 * @param studentName
	 * @param examdate
	 * @param studentresult
	 * @return
	 */
	int getMorningResultInfoCount(String classId, String studentName, String examdate, String studentresult);

	/**
	 * �޸ĳ�����Ϣ
	 * 
	 * @param stuRes
	 * @return
	 */
	boolean UpdateMorningResultInfo(StudnetVOresultInfo stuRes);

	/**
	 * ɾ��������Ϣ
	 * 
	 * @param id
	 * @return
	 */
	boolean deleteMorningResultInfo(String id);

	/**
	 * ��ѯ�ܿ��ɼ�
	 * 
	 * @return
	 */
	List<StudnetVOresultInfo> ShowWeekResultInfoList(String classId, String studentName, String examdate,
			String studentresult, String resultId, int currentPageNo, int pageSize);

	/**
	 * ��ȡ�ܿ��ɼ����ܼ�¼��
	 * 
	 * @param classId
	 * @param studentName
	 * @param examdate
	 * @param studentresult
	 * @return
	 */
	int getWeekResultInfoCount(String classId, String studentName, String examdate, String studentresult);

	/**
	 * �޸��ܿ���Ϣ
	 * 
	 * @param stuRes
	 * @return
	 */
	boolean UpdateWeekResultInfo(StudnetVOresultInfo stuRes);

	/**
	 * ɾ���ܿ���Ϣ
	 * 
	 * @param id
	 * @return
	 */
	boolean deleteWeekResultInfo(String id);
}
