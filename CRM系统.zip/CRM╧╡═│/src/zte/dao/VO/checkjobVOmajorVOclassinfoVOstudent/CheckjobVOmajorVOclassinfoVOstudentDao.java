package zte.dao.VO.checkjobVOmajorVOclassinfoVOstudent;

import java.util.List;

import zte.entity.VO.CheckjobVOmajorVOclassinfoVOstudent;

public interface CheckjobVOmajorVOclassinfoVOstudentDao {

	/**
	 * ��ҵ ��ҳ��ѯ
	 * 
	 * @param ckStatu
	 * @param id
	 * @param studyType
	 * @param currentPageNo
	 * @param pageSize
	 * @return
	 */
	List<CheckjobVOmajorVOclassinfoVOstudent> ShowcheckjobVOmajorVOclassinfoVOstudent(String ckStatu, String id,
			String studyType, int currentPageNo, int pageSize);

	/**
	 * ��ҵ �ܼ�¼��
	 * 
	 * @param id1
	 * @param studyType1
	 * @return
	 */
	int getcheckjobVOmajorVOclassinfoVOstudent(String id1, String studyType1);
}
