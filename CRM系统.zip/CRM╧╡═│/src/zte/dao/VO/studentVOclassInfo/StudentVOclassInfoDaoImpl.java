package zte.dao.VO.studentVOclassInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import zte.dao.BaseDao;
import zte.entity.VO.StudentVOclassInfo;

public class StudentVOclassInfoDaoImpl extends BaseDao implements StudentVOclassInfoDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public List<StudentVOclassInfo> ShowstudentOVclassInfoList(String StudyType, String ClassId, String StudentName,
			int currentPage, int pageSize) {

		List<StudentVOclassInfo> studentList = new ArrayList<StudentVOclassInfo>();
		conn = this.getConnection();
		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer(
				"select *\r\n" + "from(\r\n" + "select rownum rn,s.*,c.classname,c.studytype from ztestudent s\r\n"
						+ "inner join zteclassInfo c on s.classid=c.classid\r\n" + "where 1=1 ");
		if (StudyType != null && !"".equals(StudyType)) {
			sql.append(" and c.studytype=? ");
			// �������������ӵ�����������
			params.add(StudyType);
		}
		if (StudentName != null && !"".equals(StudentName)) {
			sql.append(" and s.studentname like ? ");
			// �������������ӵ�����������
			params.add("%" + StudentName + "%");
		}

		if (ClassId != null && !"".equals(ClassId)) {
			// �������������ӵ�����������
			sql.append(" and c.classid=? ");
			params.add(ClassId);
		}
		// ƴ��SQL���
		if (currentPage != 0) {
			sql.append(" and  rownum<=?   ");
		} else {
			sql.append(" and  0=?  ");
		}

		sql.append(" ) where rn>? ");

		// rownum���� ����ǰҳ��*ҳ��ߴ�
		params.add(currentPage * pageSize);
		// rn������(��ǰҳ��-1)*ҳ��ߴ�
		params.add((currentPage - 1) * pageSize);

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String studentId = rs.getString("studentId");
				String studentName = rs.getString("studentName");
				String classId = rs.getString("classId");
				String fromSchool = rs.getString("fromSchool");
				String education = rs.getString("education");
				String loginCode = rs.getString("loginCode");
				String password = rs.getString("password");
				String className = rs.getString("className");
				String studyType = rs.getString("studyType");

				StudentVOclassInfo student = new StudentVOclassInfo(studentId, studentName, classId, fromSchool,
						education, loginCode, password, className, studyType);
				studentList.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return studentList;

	}

	@Override
	public int getStudentOVclassInfoCount(String studyType, String classId, String studentName) {
		int totalCount = 0;// ��ҳ��ѯ��������
		conn = this.getConnection();
		StringBuffer sql = new StringBuffer("select count(*) from ztestudent s\r\n"
				+ "inner join zteclassInfo c on s.classid=c.classid\r\n" + "where 1=1 ");
		List<Object> params = new ArrayList<Object>();
		if (studyType != null && !"".equals(studyType)) {
			sql.append(" and c.studytype=? ");
			// �������������ӵ�����������
			params.add(studyType);
		}
		if (studentName != null && !"".equals(studentName)) {
			sql.append(" and s.studentname like ?");
			// �������������ӵ�����������
			params.add("%" + studentName + "%");
		}

		if (classId != null && !"".equals(classId)) {
			// �������������ӵ�����������
			sql.append(" and c.classid=? ");
			params.add(classId);
		}
		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				totalCount = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return totalCount;
	}

	@Override
	public StudentVOclassInfo getStudentInfo(String stuNo) {
		StudentVOclassInfo studentInfo = null;

		conn = this.getConnection();
		String sql = "select s.studentid,s.studentname,s.fromschool,s.education,s.logincode,s.password,c.classname,c.studytype from   ztestudent s\r\n"
				+ "inner join zteclassInfo c on s.classid=c.classid\r\n" + "where s.studentid=? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, stuNo);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String studentId = rs.getString("studentid");
				String studentName = rs.getString("studentname");
				String fromSchool = rs.getString("fromschool");
				String education = rs.getString("education");
				String loginCode = rs.getString("logincode");
				String password = rs.getString("password");
				String className = rs.getString("classname");
				String studyType = rs.getString("studytype");

				// �����ݷ�װ����������ȥ
				studentInfo = new StudentVOclassInfo(studentId, studentName, fromSchool, education, loginCode, password,
						className, studyType);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return studentInfo;
	}

	public int getStudentOVclassInfoCount(String className1, String studentName) {
		int totalCount = 0;// ��ҳ��ѯ��������
		conn = this.getConnection();
		StringBuffer sql = new StringBuffer("select count(*) from ztestudent s\r\n"
				+ "inner join zteclassInfo c on s.classid=c.classid\r\n" + "where 1=1 ");
		List<Object> params = new ArrayList<Object>();

		if (studentName != null && !"".equals(studentName)) {
			sql.append(" and s.studentname like ?");
			// �������������ӵ�����������
			params.add("%" + studentName + "%");
		}

		if (className1 != null && !"".equals(className1)) {
			// �������������ӵ�����������
			sql.append(" and c.className like ? ");
			params.add("%" + className1 + "%");
		}
		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				totalCount = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return totalCount;
	}

	@Override
	public List<StudentVOclassInfo> ShowstudentOVclassInfoList(String className1, String studentName, int currentPageNo,
			int pageSize) {
		List<StudentVOclassInfo> studentList = new ArrayList<StudentVOclassInfo>();
		conn = this.getConnection();
		// ��������ֵ
		List<Object> params = new ArrayList<Object>();
		StringBuffer sql = new StringBuffer(
				"select *\r\n" + "from(\r\n" + "select rownum rn,s.*,c.classname,c.studytype from ztestudent s\r\n"
						+ "inner join zteclassInfo c on s.classid=c.classid\r\n" + "where 1=1 ");

		if (studentName != null && !"".equals(studentName)) {
			sql.append(" and s.studentname like ? ");
			// �������������ӵ�����������
			params.add("%" + studentName + "%");
		}

		if (className1 != null && !"".equals(className1)) {
			// �������������ӵ�����������
			sql.append(" and c.className like ? ");
			params.add("%" + className1 + "%");
		}
		// ƴ��SQL���
		if (currentPageNo != 0) {
			sql.append(" and  rownum<=?   ");
		} else {
			sql.append(" and  0=?  ");
		}

		sql.append(" ) where rn>? ");

		// rownum���� ����ǰҳ��*ҳ��ߴ�
		params.add(currentPageNo * pageSize);
		// rn������(��ǰҳ��-1)*ҳ��ߴ�
		params.add((currentPageNo - 1) * pageSize);

		try {
			pstmt = conn.prepareStatement(sql.toString());
			// ���ݲ���
			for (int i = 0; i < params.size(); i++) {
				pstmt.setObject((i + 1), params.get(i));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String studentId = rs.getString("studentId");
				String studentName1 = rs.getString("studentName");
				String classId = rs.getString("classId");
				String fromSchool = rs.getString("fromSchool");
				String education = rs.getString("education");
				String loginCode = rs.getString("loginCode");
				String password = rs.getString("password");
				String className = rs.getString("className");
				String studyType = rs.getString("studyType");

				StudentVOclassInfo student = new StudentVOclassInfo(studentId, studentName1, classId, fromSchool,
						education, loginCode, password, className, studyType);
				studentList.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeAll(conn, pstmt, rs);
		}
		return studentList;
	}

}
