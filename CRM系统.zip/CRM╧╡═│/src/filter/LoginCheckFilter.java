package filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * �����ж������Ƿ��е�½���session ���û��˵�����ȵ�¼�ķǷ�����
 * Servlet Filter implementation class LoginCheckFilter
 */
@WebFilter(urlPatterns ={"/market/*","/report/*","/studentManager/*"})
public class LoginCheckFilter implements Filter {

   public void init(FilterConfig fConfig) throws ServletException {
	}
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

//			HttpServletRequest request2=(HttpServletRequest)request;
//			HttpServletResponse response2=(HttpServletResponse)response;
//			String path = request2.getRequestURI();
//			System.out.println("����"+path+"1230");
//			HttpSession session=request2.getSession();
//			String userSession=(String)session.getAttribute("userSession");
//			if (null!=userSession) {
//				chain.doFilter(request2, response2);
//			}else {
//				//�Ƿ�����
//				response2.sendRedirect(request2.getContextPath()+"/401.jsp");
//			}
					
		}
		
		
		
		
	}
	


