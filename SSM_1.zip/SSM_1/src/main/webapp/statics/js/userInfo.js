var uCode = null;
var uName = null;
var uGender = null;
var uBirthday = null;
var uPhone = null;
var uRole = null;
var uAddress = null;
var a_idPicPath=null;
var dizhi=null;

$(function(){
	$(".viewUser").on("click",function(){
		
			$('#xiangqing').css('display', 'block');
			
			
		//将被绑定的元素（a）转换成jquery对象，可以使用jquery方法
		var obj = $(this);
	$.ajax({
		type:"GET",//请求类型
		url:path+"/user/userInfo.html",//请求的url
		data:{method:"getrolelist",userid:obj.attr("userid")},//请求参数
		dataType:"json",//ajax接口（请求url）返回的数据类型
		success:function(data){//data：返回数据（json对象）
			if(data != null){
			
				$("#uCode").val(data.userCode);
				$("#uName").val(data.userName);
				if(data.gender=="1"){
					$("#uGender").val("女");
				}else if(data.gender=="2"){
					$("#uGender").val("男");
				}
				$("#uBirthday").val(data.birthday);
				$("#uPhone").val(data.phone);		
				$("#uRole").val(data.userRoleName);
				$("#uAddress").val(data.address);
				/*$("#a_idPicPath").src=(data.idPicPath);*/
				//$("#a_idPicPath").attr("src","F:\Tomcat\apache-tomcat-9.0.39-windows-x64\apache-tomcat-9.0.39\webapps\SpringMvcDay2_2\+data.idPicPath");
              //alert('验证用户出现场错误，请稍后再试');
    
				}}
	});});});
	

$(function(){
	$("#buu").on("click",function(){	 
	   $('#xiangqing').css('display', 'none');
	   }); 
});




/*
*/





	