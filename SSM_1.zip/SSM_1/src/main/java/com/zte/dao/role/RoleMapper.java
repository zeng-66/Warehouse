package com.zte.dao.role;

import java.util.List;

import com.zte.pojo.Role;



public interface RoleMapper {

	public List<Role> getRoleList();
}
