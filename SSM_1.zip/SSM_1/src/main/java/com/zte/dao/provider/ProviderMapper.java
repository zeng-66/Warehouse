package com.zte.dao.provider;


import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zte.pojo.Provider;

public interface ProviderMapper {

	/**
	 * 增加供应商
	 * 
	 * @param provider
	 * @return
	 */
	int add(Provider provider);

	/**
	 * 通过供应商名称、编码获取供应商列表-模糊查询-providerList
	 * 
	 * @param proName
	 * @param proCode
	 * @param currentPageNo
	 * @param pageSize
	 * @return
	 */
	List<Provider> getProviderList(
			@Param("proName")String proName, 
			@Param("proCode")String proCode, 
			@Param("currentPageNo")int currentPageNo, 
			@Param("pageSize")int pageSize);

	/**
	 * 通过条件查询-供应商表记录数
	 * 
	 * @param proName
	 * @param proCode
	 * @return
	 * @throws Exception
	 */
	int getproviderCount(
			@Param("proName")String proName, 
			@Param("proCode")String proCode);

	/**
	 * 通过proId删除Provider
	 * 
	 * @param delId
	 * @return
	 */
	int deleteProviderById(@Param("delId")String delId);

	/**
	 * 通过proId获取Provider
	 * 
	 * @param id
	 * @return
	 */
	Provider getProviderById(@Param("id")String id);

	/**
	 * 修改用户信息
	 * 
	 * @param user
	 * @return
	 */
	int modify(Provider provider);
	
	
	/**
	 * 	获取Provider全部信息
	 * @return
	 */
	List<Provider> proList();

}
