package com.zte.dao.bill;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zte.pojo.Bill;


public interface BillMapper {

	/**
	 * 增加订单
	 * @param connection
	 * @param bill
	 * @return
	 * @throws Exception
	 */
	 int add(Bill bill);


	/**
	 * 通过查询条件获取供应商列表-模糊查询-getBillList
	 * @param connection
	 * @param bill
	 * @return
	 * @throws Exception
	 */
	List<Bill> getBillList(
			@Param(value = "productName")String productName, 
			@Param(value = "providerId")int providerId, 
			@Param(value = "isPayment")int isPayment ,
			@Param(value = "currentPageNo")int currentPageNo,
			@Param(value = "pageSize")int pageSize);
	
	/**
	 * 通过delId删除Bill
	 * @param connection
	 * @param delId
	 * @return
	 * @throws Exception
	 */
	int deleteBillById(@Param("delId")String delId); 
	
	
	/**
	 * 通过billId获取Bill
	 * @param connection
	 * @param id
	 * @return
	 * @throws Exception
	 */
	Bill getBillById(@Param("id")String id); 
	
	/**
	 * 修改订单信息
	 * @param connection
	 * @param bill
	 * @return
	 * @throws Exception
	 */
	int modify(Bill bill);

	/**
	 * 根据供应商ID查询订单数量
	 * @param connection
	 * @param providerId
	 * @return
	 * @throws Exception
	 */
	int getBillCount(
			@Param("productName")String productName ,
			@Param("providerId")int providerId, 
			@Param("isPayment")int isPayment);
}
