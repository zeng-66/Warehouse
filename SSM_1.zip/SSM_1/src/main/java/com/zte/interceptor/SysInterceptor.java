package com.zte.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.zte.pojo.User;
import com.zte.tools.Constants;

/**
 * 	Interceptor是SpringMVC的拦截器作用相当于Servlet的Filter
          我们在这在每个语求之前先走到拦截器判断是否有登录的session如果没有登录的session的，
	说明没有登录，去401.jsp页面
 * @author zeng
 *
 */
public class SysInterceptor  extends HandlerInterceptorAdapter{

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(Constants.USER_SESSION);
		if (null==user) {
			response.sendRedirect(request.getContextPath()+"/401.jsp");
			return false;
		}
		return true;
	}
}
