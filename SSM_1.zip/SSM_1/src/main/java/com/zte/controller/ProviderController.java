package com.zte.controller;

import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSONArray;
import com.mysql.cj.util.StringUtils;
import com.zte.pojo.Provider;
import com.zte.service.provider.ProviderService;
import com.zte.tools.Constants;
import com.zte.tools.PageSupport;



@Controller
@RequestMapping("/provider")
public class ProviderController {

	private Logger logger = Logger.getLogger(UserController.class);
	
	@Resource
	private ProviderService providerService;


	@RequestMapping("/providerList.html")
	public String providerList(
			@RequestParam(value = "queryProCode", required = false) String queryProCode,
			@RequestParam(value = "queryProName", required = false) String queryProName,
			@RequestParam(value = "pageIndex", required = false) String pageIndex, 
			Model model){	
		List<Provider> providerList = null;
		String proCode =null;
		String proName =null;
		int pageSize = Constants.pageSize;
		int currentPageNo = 1;
		if (queryProCode != null && !"".equals(queryProCode)) {
			proCode = queryProCode;
		}
		if (queryProName != null && !"".equals(queryProName)) {
			proName = queryProName;
		}
		if (pageIndex != null) {
			currentPageNo = Integer.parseInt(pageIndex);
		}
		int totalCount = providerService.getproviderCount(proName, proCode);
		PageSupport pages = new PageSupport();
		pages.setCurrentPageNo(currentPageNo);
		pages.setPageSize(pageSize);
		pages.setTotalCount(totalCount);
		int totalPageCount = pages.getTotalPageCount();
		if (currentPageNo < 1) {
			currentPageNo = 1;
		} else if (currentPageNo > totalPageCount) {
			currentPageNo = totalPageCount;
		}
		providerList = providerService.getProviderList(proName, proCode, currentPageNo, pageSize);
		model.addAttribute("totalCount", totalCount);
		model.addAttribute("totalPageCount", totalPageCount);
		model.addAttribute("currentPageNo", currentPageNo);
		model.addAttribute("queryProCode", queryProCode);
		model.addAttribute("queryProName", queryProName);
		model.addAttribute("providerList", providerList);
		for (Provider provider : providerList) {
			System.out.println(provider.toString());
		}
		return "/provider/providerlist";	
	}
	
	
	
	@RequestMapping("/toadd.html")
	public String doadd(Model model) {
		
		return "/provider/provideradd";
	}
	
	@RequestMapping(value = "/proaddsave.html", method = RequestMethod.POST)
	public String addPro(Provider pro, HttpSession session) {
		
		if (providerService.add(pro)) {
			return "redirect:/provider/providerList.html";
		}
		return "/provider/provideradd";
	}
	
	
	
	@RequestMapping("/deletePro.html")
	@ResponseBody //此注解的作用是将Json数据响应到客户端，相当于out.print(data) ;
	public Object deletePro(@RequestParam(value = "proid") String proid) {
		HashMap<String, String> resultMap=new HashMap<String, String>();
		if(!StringUtils.isNullOrEmpty(proid)){
			int flag = providerService.deleteProviderById(proid);
			if(flag == 0){//删除成功
//				resultMap.put("delResult", "true");
				return "true";
			}else if(flag == -1){//删除失败
//				resultMap.put("delResult", "false");
				return "false";
			}else if(flag > 0){//该供应商下有订单，不能删除，返回订单数
//				resultMap.put("delResult", String.valueOf(flag));
				return flag;
			}
		}else{
			return"notexit";
		}
		return "false";
	}
	
	
	
	@RequestMapping(value = "proModify.html")
	public String modify(@RequestParam(value = "proid") String proid, Model model) {
		logger.debug("uid=========" + proid);
		Provider pro = providerService.getProviderById(proid);
		model.addAttribute("provider", pro);
		return "/provider/providermodify";

	}

	@RequestMapping(value = "/promodifysave.html", method = RequestMethod.POST)
	public String promodifysave(Provider pro, HttpSession session) {
		if (providerService.modify(pro)) {
			return "redirect:/provider/providerList.html";
		}
		return "/provider/providermodify";
	}
	
	
	@RequestMapping(value = "/view.html", method = RequestMethod.GET)
	public String view(@RequestParam("proid") String proid, Model model) {
		logger.debug("view id ----------->"+proid);
		Provider pro = providerService.getProviderById(proid);
		model.addAttribute("provider",pro);
		return "provider/providerview";
	}
}
