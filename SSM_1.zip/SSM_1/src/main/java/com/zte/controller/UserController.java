package com.zte.controller;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.server.PathParam;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import com.mysql.cj.util.StringUtils;
import com.zte.pojo.Role;
import com.zte.pojo.User;
import com.zte.service.role.RoleService;
import com.zte.service.user.UserService;
import com.zte.tools.Constants;
import com.zte.tools.PageSupport;



@Controller
@RequestMapping("/user")
public class UserController {

	private Logger logger = Logger.getLogger(UserController.class);

	@Resource
	private UserService userService;
	
	@Resource
	private RoleService roleService;

	@RequestMapping(value = "/login.html")
	public String login(@RequestParam(value = "userCode") String userCode,
			@RequestParam(value = "userPassword") String userPassword, HttpServletRequest request,
			HttpSession session) {
		User user = null;
		user = userService.login(userCode, userPassword);
		if (user == null) {
			// 登录失败则到login.jsp
			request.setAttribute("error", "用户名或密码错误！");
			return "login";
		} else {
			// 登入成功保存session
			session.setAttribute(Constants.USER_SESSION, user);
//			return "frame";
//			return "redirect:/user/sys/main.html";
			return "redirect:/user/sys/main.html";
		}
	}

	@RequestMapping("/sys/main.html")
	public String main() {
		return "frame";
	}
	
	
	@RequestMapping("/tologin.html")
	public String tologin() {
		return "login";
	}
	
	@RequestMapping("/logout.html")
	public String logout(HttpSession session) {
		// session.invalidate();
		session.removeAttribute(Constants.USER_SESSION);
		return "login";
	}
	
	
	@RequestMapping("/userList.html")
	public String getUserList(@RequestParam(value = "queryname", required = false) String queryname,
			@RequestParam(value = "queryUserRole", required = false) String queryUserRole,
			@RequestParam(value = "pageIndex", required = false) String pageIndex, Model model) {
		logger.info("getUserList--------------》queryname=" + queryname);
		logger.info("getUserList--------------》queryUserRole=" + queryUserRole);
		logger.info("getUserList--------------》pageIndex=" + pageIndex);
		int _queryUserRole = 0;
		List<User> userList = null;
		int pageSize = Constants.pageSize;
		int currentPageNo = 1;
		if (queryname == null) {
			queryname = "";
		}
		if (queryUserRole != null && !"".equals(queryUserRole)) {
			_queryUserRole = Integer.parseInt(queryUserRole);
			
		}
		if (pageIndex != null) {
			currentPageNo = Integer.parseInt(pageIndex);
		}
		int totalCount = userService.getUserCount(queryname, _queryUserRole);
		PageSupport pages = new PageSupport();
		pages.setCurrentPageNo(currentPageNo);
		pages.setPageSize(pageSize);
		pages.setTotalCount(totalCount);
		int totalPageCount = pages.getTotalPageCount();
		if (currentPageNo < 1) {
			currentPageNo = 1;
		} else if (currentPageNo > totalPageCount) {
			currentPageNo = totalPageCount;
		}
		userList = userService.getUserList(queryname, _queryUserRole, currentPageNo, pageSize);
		List<Role> roleList = null;
		roleList = roleService.getRoleList();
		model.addAttribute("userList", userList);
		model.addAttribute("roleList", roleList);
		model.addAttribute("queryUserRole", _queryUserRole);
		model.addAttribute("queryname", queryname);
		model.addAttribute("totalCount", totalCount);
		model.addAttribute("totalPageCount", totalPageCount);
		model.addAttribute("currentPageNo", currentPageNo);
		return "/user/userlist";
	}
	
	@RequestMapping(value = "/userInfo.html")
	@ResponseBody
	public User userInfo(@RequestParam("userid") String userid ,Model model) {
		User user = userService.getUserById(userid);	
		return user;	
	}
	
	@RequestMapping("/doadd.html")
	public String doadd(Model model) {
		List<Role> roleList = (List<Role>) roleService.getRoleList();
		model.addAttribute(roleList);
		return "/user/useradd";
	}
	
	@RequestMapping("/chaUser.html")
	@ResponseBody
	public String chaUser(@RequestParam("userCode") String userCode) {	
		if (null!=userService.selectUserCodeExist(userCode)) {
			return "exist";
		}
		return " ";	
	}

	
	@RequestMapping(value = "/useraddsave.html")
	public String addUser(
			User user, 
			HttpSession session,
			HttpServletRequest request,
			@RequestParam(value = "a_idPicPath",required = false) //设置证件照不是必须，用MultipartFile类型接收
			MultipartFile attach) throws IOException {	
		String idPicPath="";
		if (!attach.isEmpty()) {
			//文件上传路径
		String path = request.getSession().getServletContext().getRealPath("statics"+File.separator+"uploadfiles");
		logger.debug("------------------->文件上传路径："+path);
		//拷贝一份
		//this.copyTP(path);
			//获取文件名称
		String oldFileaName = attach.getOriginalFilename();
			//文件格式---》后缀
		String stuFix = FilenameUtils.getExtension(oldFileaName);
		int fileSize=50000000;
		if (attach.getSize()>fileSize) {
			//超出大小
			request.setAttribute("uploadFileError", "--文件上传大小不能超过5000KB");
			return "/user/useradd";
		}else {
			List<String> typeList = Arrays.asList("jpg","jpeg","png","gif");
			if (typeList.contains(stuFix)) {
				//将上传的文件,生成一个新的文明名称〔主要是避免重复〉
				String fileName = System.currentTimeMillis()+RandomUtils.nextInt(1000000)+"_Personal.jpg";
				logger.debug("------------------->上传新文件名称："+fileName);
				//file对象 = 服务器地址加文件名
				File targeFile = new File(path, fileName);
				if (!targeFile.exists()) {
					//如果路径不存在就递归创建该目录
					targeFile.mkdirs();
				}			
					  //1、将文件上传到服务器存储图片目录上
					try {
						attach.transferTo(targeFile);
					} catch (IllegalStateException | IOException e) {
						request.setAttribute("uploadFileError", "文件上传失败！");
						e.printStackTrace();
					}
					//2、.将文件的url地址保持到数据库
					idPicPath="statics\\uploadfiles\\"+fileName;		
			}else {
				//格式不对
				request.setAttribute("uploadFileError", "上传的格式文件不是jpg、jpeg、png、gif格式的文件！");
				return "/user/useradd";
			}	
		}	
		}
		//获职到登录的用户，将登录的这个的用户的ID插入到创理人ID里面去
		User userSession =(User) session.getAttribute(Constants.USER_SESSION);
		user.setCreatedBy(userSession.getId());
		user.setCreationDate(new Date());
		user.setIdPicPath(idPicPath); //将上传文件的路径URL存入到数据库的idpicpath字段
		if (userService.add(user)) {		
			return "redirect:/user/userList.html";
		}
		return "/user/useradd";
	}

	
	@RequestMapping(value = "userModify.html")
	public String modify(@RequestParam(value = "uid") String uid, Model model) {
		logger.debug("uid=========" + uid);
		User user = userService.getUserById(uid);
		model.addAttribute("user", user);
		return "/user/usermodify";

	}

	@RequestMapping(value = "/usermodifysave.html", method = RequestMethod.POST)
	public String usermodifysave(User user, HttpSession session) {
		if (userService.modify(user)) {
			return "redirect:/user/userList.html";
		}
		return "/user/usermodify";
	}

	/**
	 * 	REST风格请求/user/view/{id}
	 * 	注意:一定要加@Pathvariable注释!
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public String view(@PathVariable String id, Model model) {
		logger.debug("view id ----------->"+id);
		User user = userService.getUserById(id);
		model.addAttribute(user);
		return "/user/userview";
	}

	
	@RequestMapping("/deleteuser.html")
	@ResponseBody //此注解的作用是将Json数据响应到客户端，相当于out.print(data) ;
	public Object deleteUser(@RequestParam(value = "uid") String uid) {
		if (StringUtils.isNullOrEmpty(uid)) {
			return "nouid";
		}else {
			if (userService.deleteUserById(Integer.parseInt(uid))) {
				return "cuccess";
			}else {	
				return "fail";
			}
		}
	}
	
	@RequestMapping("/toUpPwd.html")
	public String toUpPwd() {		
		return "/user/pwdmodify";
		
	}
	
	
	@RequestMapping("/yanzheng.html")
	@ResponseBody
	public String upPWD(
			@Param(value = "oldpassword") String oldpassword,HttpSession session,
			@Param(value = "newpassword") String newpassword) {
		User userSession =(User) session.getAttribute(Constants.USER_SESSION);
		if (null==userSession ) {
			return "sessionerror";
		}else {
			String ss = userSession.getId().toString();
			User user = userService.getUserById(ss);
			if (null==user) {
				return "false";
			}else if (oldpassword==user.getUserPassword()||oldpassword.equals(user.getUserPassword())) {
				logger.debug("oldpassword------------->"+oldpassword);
				logger.debug("newpassword------------->"+newpassword);
				logger.debug("id------------->"+ss);
				
				System.out.println(oldpassword);
				System.out.println(newpassword);
				System.out.println(ss);
				
				
				return "true";
			}else {
				return "error";
			}
		}
	}
	
	@RequestMapping("/uppwd.html")
	public String uppwd(@Param(value = "oldpassword") String oldpassword,HttpSession session,
			@Param(value = "newpassword") String newpassword, Model model) {
		User userSession =(User) session.getAttribute(Constants.USER_SESSION);
		if (userService.updatePwd(userSession.getId(), newpassword)) {
			model.addAttribute("info","修改成功！");
		}
		model.addAttribute("info","修改失败！");
		return "/user/pwdmodify";
		
		
	} 
	
	
}
