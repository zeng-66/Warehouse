package com.zte.controller;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zte.pojo.Bill;
import com.zte.pojo.Provider;
import com.zte.service.bill.BillService;
import com.zte.service.provider.ProviderService;
import com.zte.tools.Constants;
import com.zte.tools.PageSupport;

@Controller
@RequestMapping("/bill")
public class BillController {

	private Logger logger = Logger.getLogger(UserController.class);
	
	@Resource
	BillService billService;
	@Resource
	ProviderService providerService;
	
	@RequestMapping("/billlist.html")
	public String providerList(
			@RequestParam(value = "queryProductName", required = false) String queryProductName,
			@RequestParam(value = "queryProviderId", required = false) String queryProviderId,
			@RequestParam(value = "queryIsPayment", required = false) String queryIsPayment,
			@RequestParam(value = "pageIndex", required = false) String pageIndex,
			
			Model model){	
		List<Bill> BillList = null;
		List<Provider> providerList= null;
		String productName =null;
		String providerId =null;
		String isPayment=null;
		int is = 0;
		int id = 0;
		
		int pageSize = Constants.pageSize;
		int currentPageNo = 1;
		if (queryProductName != null && !"".equals(queryProductName)) {
			productName = queryProductName;
		}
		if (queryProviderId != null && !"".equals(queryProviderId)) {
			providerId = queryProviderId;
			id = Integer.parseInt(providerId);
		}
		if (queryIsPayment != null && !"".equals(queryIsPayment)) {
			isPayment = queryIsPayment;
			is = Integer.parseInt(isPayment);
		}
		if (pageIndex != null) {
			currentPageNo = Integer.parseInt(pageIndex);
		}
		int totalCount = billService.getBillCount(productName,id,is);
		PageSupport pages = new PageSupport();
		pages.setCurrentPageNo(currentPageNo);
		pages.setPageSize(pageSize);
		pages.setTotalCount(totalCount);
		int totalPageCount = pages.getTotalPageCount();
		if (currentPageNo < 1) {
			currentPageNo = 1;
		} else if (currentPageNo > totalPageCount) {
			currentPageNo = totalPageCount;
		}
		providerList = providerService.getProviderList();
		BillList = billService.getBillList(productName,id,is,currentPageNo, pageSize);
		model.addAttribute("totalCount", totalCount);
		model.addAttribute("totalPageCount", totalPageCount);
		model.addAttribute("currentPageNo", currentPageNo);
		model.addAttribute("queryProductName", queryProductName);
		model.addAttribute("queryProviderId", queryProviderId);
		model.addAttribute("queryIsPayment", queryIsPayment);
		model.addAttribute("billList", BillList);
		model.addAttribute("providerList",providerList);	
		return "/bill/billlist";	
	}
	
	
	@RequestMapping("/deleteBill.html")
	@ResponseBody
	public String deleteBill(@Param(value = "billid") String billid ) {
		
		if (billService.deleteBillById(billid)) {
			return "true";
		}
		return "false";		
	}
	
	
	@RequestMapping("/toAdd.html")
	public String toAddBill(Model model) {
		List<Provider> providerList= null;
		providerList = providerService.getProviderList();
		model.addAttribute(providerList);
		return "/bill/billadd";	
	}
	
	@RequestMapping("/addBill.html")
	public String addBill(Bill bill , Model model) {	
		if (billService.add(bill)) {
			model.addAttribute("info" , "添加成功！");
		}	
		model.addAttribute("info" , "添加失败！");
		return "/bill/billadd";	
	}
	
	
	@RequestMapping("/toModify.html")
	public String toBillModify(@Param(value = "billid")String billid, Model model) {	
		Bill bill = billService.getBillById(billid);
		List<Provider> providerList= null;
		providerList = providerService.getProviderList();
		model.addAttribute(providerList);
		model.addAttribute("bill",bill);
		return "/bill/billmodify";	
	}
	
	@RequestMapping("/billModify.html")
	public String BillModify(Bill bill , Model model) {
		if (billService.modify(bill)) {
		}
		return "redirect:/bill/billlist.html";
		
	}
	
	
	@RequestMapping("/getBillInfo.html")
	public String billInfo(@Param(value = "billid")String billid, Model model) {
		Bill bill = null;
		bill = billService.getBillById(billid);
		model.addAttribute("bill",bill);
		System.out.println("bill---------------->"+bill);
		return "/bill/billview";
		
	}
	
}
