package com.zte.service.role;

import java.util.List;

import com.zte.pojo.Role;



public interface RoleService {
	
	public List<Role> getRoleList();
	
}
