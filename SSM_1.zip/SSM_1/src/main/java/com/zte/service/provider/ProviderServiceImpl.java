package com.zte.service.provider;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import com.zte.dao.provider.ProviderMapper;
import com.zte.pojo.Provider;

@Service
public class ProviderServiceImpl implements ProviderService {

	@Resource
	ProviderMapper providerMapper;

	@Override
	public boolean add(Provider provider) {
		if (providerMapper.add(provider) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<Provider> getProviderList(String proName, String proCode, int currentPageNo, int pageSize) {
		currentPageNo = (currentPageNo - 1) * pageSize;
		return providerMapper.getProviderList(proName, proCode, currentPageNo, pageSize);
	}

	@Override
	public int getproviderCount(String proName, String proCode) {
		return providerMapper.getproviderCount(proName, proCode);
	}

	@Override
	public int deleteProviderById(String delId) {	
		return providerMapper.deleteProviderById(delId);
	}

	@Override
	public Provider getProviderById(String id) {
		return providerMapper.getProviderById(id);
	}

	@Override
	public boolean modify(Provider provider) {
		if (providerMapper.modify(provider)>0) {
			return true;
		}
		return false;
	}

	@Override
	public List<Provider> getProviderList() {		
		return providerMapper.proList();
	}

}
