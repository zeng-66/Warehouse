package com.zte.service.bill;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zte.dao.bill.BillMapper;
import com.zte.pojo.Bill;

@Service
public class BillServiceImpl implements BillService {

	@Resource
	BillMapper billMapper;
	
	@Override
	public boolean add(Bill bill) {
		if (billMapper.add(bill)>0) {
			return true;
		}
		return false;
	}

	@Override
	public List<Bill> getBillList(String productName, int providerId, int isPayment ,int currentPageNo,int pageSize) {	
		currentPageNo = (currentPageNo - 1) * pageSize;
		return billMapper.getBillList(productName,providerId,isPayment,currentPageNo, pageSize);
	}

	@Override
	public boolean deleteBillById(String delId) {
		if (billMapper.deleteBillById(delId)>0) {
			return true;
		}
		return false;
	}

	@Override
	public Bill getBillById(String id) {		
		return billMapper.getBillById(id);
	}

	@Override
	public boolean modify(Bill bill) {	
		if (billMapper.modify(bill)>0) {
			return true;
		}
		return false;
	}

	@Override
	public int getBillCount(String productName, int providerId, int isPayment) {	
		return billMapper.getBillCount(productName,providerId,isPayment);
	}

}
